import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Vazirmatn } from "next/font/google";
import { StoreProvider } from "@/components/store-provider";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { CartDrawer } from "@/components/cart-drawer";
import { Toaster } from "@/components/toaster";
import { ensureSeeded } from "@/db/seed";
import { getAllCategories, getSettings } from "@/lib/queries";
import { buildColorVars } from "@/lib/admin";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "لوکسا | فروشگاه اینترنتی دیجیتال و مواد غذایی",
  description:
    "فروشگاه اینترنتی لوکسا؛ خرید محصولات دیجیتال و مواد غذایی اصل با ضمانت و ارسال سریع.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const [categories, settings] = await Promise.all([
    getAllCategories(),
    getSettings(),
  ]);

  const colorVars = buildColorVars(
    settings?.primaryColor ?? "#7c3aed",
    settings?.accentColor ?? "#ec4899",
  );

  return (
    <html lang="fa" dir="rtl" className={vazirmatn.variable}>
      <head>
        <style dangerouslySetInnerHTML={{ __html: colorVars }} />
      </head>
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <StoreProvider
          freeShipThreshold={settings?.freeShipThreshold ?? 5000000}
          shippingFee={settings?.shippingFee ?? 250000}
        >
          <Header categories={categories} settings={settings} />
          <main>{children}</main>
          <Footer categories={categories} settings={settings} />
          <CartDrawer />
          <Toaster />
        </StoreProvider>
      </body>
    </html>
  );
}
