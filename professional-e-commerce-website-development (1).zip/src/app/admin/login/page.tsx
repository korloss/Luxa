"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function AdminLoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا");
      router.push("/admin");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطا در ورود");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center overflow-y-auto bg-slate-100 px-4 py-10">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-6 flex items-center justify-center gap-2">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-fuchsia-500 text-xl font-black text-white shadow-lg">L</span>
          <span className="text-2xl font-black text-ink">لوکسا</span>
        </Link>

        <div className="rounded-3xl border border-slate-100 bg-white p-8 shadow-xl">
          <div className="mb-6 text-center">
            <div className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-brand-50 text-3xl">🔐</div>
            <h1 className="text-xl font-black text-ink">پنل مدیریت</h1>
            <p className="mt-1 text-sm text-slate-500">برای ورود رمز عبور را وارد کنید</p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-bold text-slate-700">رمز عبور</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoFocus
                required
                dir="ltr"
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-center text-lg tracking-widest outline-none transition focus:border-brand-400 focus:bg-white focus:ring-4 focus:ring-brand-100"
                placeholder="••••••"
              />
            </div>

            {error && (
              <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-center text-sm font-bold text-rose-600">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand-500/30 transition hover:opacity-90 disabled:opacity-50"
            >
              {loading ? "در حال ورود..." : "ورود به پنل"}
            </button>
          </form>
        </div>

        <p className="mt-4 text-center text-xs text-slate-400">
          🔒 این بخش فقط برای مدیران سایت قابل دسترس است
        </p>
      </div>
    </div>
  );
}
