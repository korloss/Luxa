import Link from "next/link";
import { getDashboardStats, getAllProducts } from "@/lib/queries";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc } from "drizzle-orm";
import { faNum, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

const statusColor: Record<string, string> = {
  "در حال پردازش": "bg-amber-100 text-amber-700",
  "ارسال شده": "bg-sky-100 text-sky-700",
  "تحویل داده شده": "bg-emerald-100 text-emerald-700",
};

export default async function AdminDashboard() {
  const [stats, products, recentOrders] = await Promise.all([
    getDashboardStats(),
    getAllProducts(),
    db.select().from(orders).orderBy(desc(orders.createdAt)).limit(6),
  ]);

  const lowStockProducts = products.filter((p) => p.stock < 10);

  const cards = [
    { label: "درآمد کل", value: faNum(stats.revenue) + " ت", icon: "💰", color: "from-emerald-500 to-teal-600" },
    { label: "سفارش‌ها", value: faNum(stats.orderCount), icon: "🧾", color: "from-brand-500 to-fuchsia-600" },
    { label: "محصولات", value: faNum(stats.productCount), icon: "📦", color: "from-sky-500 to-blue-600" },
    { label: "نظرات", value: faNum(stats.reviewCount), icon: "⭐", color: "from-amber-500 to-orange-600" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-ink">داشبورد مدیریت</h1>
        <p className="mt-1 text-sm text-slate-500">خلاصه‌ای از وضعیت فروشگاه لوکسا</p>
      </div>

      {/* stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="overflow-hidden rounded-3xl border border-slate-100 bg-white p-5">
            <div className={`mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${c.color} text-2xl`}>{c.icon}</div>
            <p className="text-xs text-slate-500">{c.label}</p>
            <p className="mt-1 text-xl font-black text-ink">{c.value}</p>
          </div>
        ))}
      </div>

      {stats.lowStock > 0 && (
        <div className="flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4">
          <span className="text-2xl">⚠️</span>
          <div className="flex-1">
            <p className="text-sm font-bold text-amber-800">{faNum(stats.lowStock)} محصول با موجودی کم</p>
            <p className="text-xs text-amber-600">موجودی این محصولات رو افزایش بدید</p>
          </div>
          <Link href="/admin/products" className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-white">مشاهده</Link>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        {/* recent orders */}
        <div className="lg:col-span-2">
          <div className="rounded-3xl border border-slate-100 bg-white p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-black text-ink">آخرین سفارش‌ها</h2>
              <Link href="/admin/orders" className="text-xs font-bold text-brand-600">همه ←</Link>
            </div>
            {recentOrders.length === 0 ? (
              <p className="py-8 text-center text-sm text-slate-400">سفارشی ثبت نشده است</p>
            ) : (
              <div className="space-y-2">
                {recentOrders.map((o) => (
                  <div key={o.id} className="flex items-center gap-3 rounded-2xl border border-slate-50 bg-slate-50/50 p-3">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-100 text-brand-700">🧾</div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-slate-800">{o.fullName}</p>
                      <p className="text-xs text-slate-400">{formatDate(o.createdAt)}</p>
                    </div>
                    <span className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold ${statusColor[o.status] ?? "bg-slate-100"}`}>{o.status}</span>
                    <span className="shrink-0 text-sm font-black text-brand-700">{faNum(o.total)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* low stock */}
        <div className="rounded-3xl border border-slate-100 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-black text-ink">موجودی کم</h2>
            <Link href="/admin/products" className="text-xs font-bold text-brand-600">همه ←</Link>
          </div>
          {lowStockProducts.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-400">همه محصولات موجودی کافی دارند ✓</p>
          ) : (
            <div className="space-y-2">
              {lowStockProducts.slice(0, 6).map((p) => (
                <div key={p.id} className="flex items-center gap-3">
                  <img src={p.image} alt="" className="h-10 w-10 rounded-lg object-cover" />
                  <p className="min-w-0 flex-1 truncate text-xs font-bold text-slate-700">{p.name}</p>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold ${p.stock === 0 ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700"}`}>
                    {faNum(p.stock)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* quick actions */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 font-black text-ink">دسترسی سریع</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {[
            { href: "/admin/products/new", label: "محصول جدید", icon: "➕" },
            { href: "/admin/categories", label: "دسته‌بندی", icon: "🗂️" },
            { href: "/admin/media", label: "آپلود تصویر", icon: "🖼️" },
            { href: "/admin/orders", label: "سفارش‌ها", icon: "🧾" },
            { href: "/admin/reviews", label: "نظرات", icon: "⭐" },
            { href: "/admin/settings", label: "تنظیمات", icon: "⚙️" },
          ].map((a) => (
            <Link key={a.href} href={a.href} className="flex flex-col items-center gap-2 rounded-2xl border border-slate-100 bg-slate-50/50 p-4 text-center transition hover:border-brand-200 hover:bg-white hover:shadow-md">
              <span className="text-2xl">{a.icon}</span>
              <span className="text-xs font-bold text-slate-700">{a.label}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
