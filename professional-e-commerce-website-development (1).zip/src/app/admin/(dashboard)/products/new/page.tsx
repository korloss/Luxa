import Link from "next/link";
import { getAllCategories } from "@/lib/queries";
import { ProductForm } from "@/components/admin/product-form";

export const dynamic = "force-dynamic";

export default async function NewProductPage() {
  const categories = await getAllCategories();
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <div>
        <Link href="/admin/products" className="mb-3 inline-flex items-center gap-1.5 text-sm font-bold text-slate-500 hover:text-brand-600">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M19 12H5M12 5l-7 7 7 7" /></svg>
          بازگشت به محصولات
        </Link>
        <h1 className="text-2xl font-black text-ink">محصول جدید</h1>
      </div>
      <ProductForm categories={categories} />
    </div>
  );
}
