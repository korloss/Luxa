import Link from "next/link";
import { getAllProducts } from "@/lib/queries";
import { faNum, discountPercent } from "@/lib/format";
import { ProductActions } from "@/components/admin/product-actions";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const products = await getAllProducts();

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-ink">مدیریت محصولات</h1>
          <p className="mt-1 text-sm text-slate-500">{faNum(products.length)} محصول</p>
        </div>
        <Link href="/admin/products/new" className="rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-brand-500/30">
          + محصول جدید
        </Link>
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-100 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50 text-right text-xs text-slate-500">
                <th className="p-4 font-bold">محصول</th>
                <th className="p-4 font-bold">دپارتمان</th>
                <th className="p-4 font-bold">قیمت</th>
                <th className="p-4 font-bold">موجودی</th>
                <th className="p-4 font-bold">امتیاز</th>
                <th className="p-4 font-bold">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => {
                const off = discountPercent(p.price, p.oldPrice);
                return (
                  <tr key={p.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img src={p.image} alt="" className="h-12 w-12 rounded-xl object-cover" />
                        <div className="min-w-0">
                          <p className="max-w-[200px] truncate font-bold text-slate-800">{p.name}</p>
                          <p className="text-xs text-slate-400">{p.brand}</p>
                        </div>
                        {p.featured && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-700">منتخب</span>}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${p.department === "food" ? "bg-emerald-100 text-emerald-700" : "bg-sky-100 text-sky-700"}`}>
                        {p.department === "food" ? "🛒 غذایی" : "💻 دیجیتال"}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className="font-bold text-slate-800">{faNum(p.price)}</span>
                      {off > 0 && <span className="mr-1 text-xs text-rose-500">-{faNum(off)}٪</span>}
                    </td>
                    <td className="p-4">
                      <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${p.stock === 0 ? "bg-rose-100 text-rose-700" : p.stock < 10 ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>
                        {faNum(p.stock)}
                      </span>
                    </td>
                    <td className="p-4 text-slate-600">⭐ {faNum(p.rating)}</td>
                    <td className="p-4">
                      <ProductActions id={p.id} slug={p.slug} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
