import { getSettings } from "@/lib/queries";
import { SettingsForm } from "@/components/admin/settings-form";

export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  const settings = await getSettings();
  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <div>
        <h1 className="text-2xl font-black text-ink">تنظیمات سایت</h1>
        <p className="mt-1 text-sm text-slate-500">
          چیدمان، رنگ‌ها، محتوای بنر و اطلاعات تماس را مدیریت کنید
        </p>
      </div>
      <SettingsForm initial={settings} />
    </div>
  );
}
