import { OrdersManager } from "@/components/admin/orders-manager";

export const dynamic = "force-dynamic";

export default function AdminOrdersPage() {
  return <OrdersManager />;
}
