"use client";

import { useState } from "react";
import Link from "next/link";
import { useStore } from "@/components/store-provider";
import { faNum } from "@/lib/format";

export default function CheckoutPage() {
  const { cart, cartTotal, clearCart, freeShipThreshold, shippingFee } = useStore();
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    notes: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [code, setCode] = useState("");

  const shipping = cartTotal >= freeShipThreshold ? 0 : shippingFee;
  const total = cartTotal + shipping;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: cart.map((i) => ({
            id: i.id,
            name: i.name,
            price: i.price,
            qty: i.qty,
            image: i.image,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا");
      setCode(data.code);
      clearCart();
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطا در ثبت سفارش");
    } finally {
      setLoading(false);
    }
  };

  // success screen
  if (code) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center gap-5 px-4 py-20 text-center">
        <div className="animate-pop grid h-24 w-24 place-items-center rounded-full bg-emerald-100 text-5xl">
          ✅
        </div>
        <h1 className="text-2xl font-black text-ink">سفارش شما ثبت شد!</h1>
        <p className="text-sm text-slate-500">
          از خرید شما سپاسگزاریم. کد رهگیری سفارش:
        </p>
        <div className="rounded-2xl border-2 border-dashed border-brand-300 bg-brand-50 px-8 py-4">
          <span className="text-2xl font-black tracking-wider text-brand-700">
            {code}
          </span>
        </div>
        <p className="text-xs text-slate-400">
          این کد را برای پیگیری سفارش نگه دارید.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3">
          <Link
            href={`/orders/${code}`}
            className="rounded-2xl bg-ink px-6 py-3 text-sm font-bold text-white transition hover:bg-brand-700"
          >
            پیگیری سفارش
          </Link>
          <Link
            href="/shop"
            className="rounded-2xl border border-slate-200 px-6 py-3 text-sm font-bold text-slate-700 transition hover:bg-slate-50"
          >
            ادامه خرید
          </Link>
        </div>
      </div>
    );
  }

  // empty cart
  if (cart.length === 0) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center gap-5 px-4 py-24 text-center">
        <div className="grid h-24 w-24 place-items-center rounded-full bg-slate-100 text-5xl">
          🛒
        </div>
        <h1 className="text-xl font-black text-ink">سبد خرید خالی است</h1>
        <Link
          href="/shop"
          className="rounded-2xl bg-ink px-6 py-3 text-sm font-bold text-white"
        >
          مشاهده محصولات
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-black text-ink sm:text-3xl">تسویه حساب</h1>

      <form onSubmit={submit} className="grid gap-6 lg:grid-cols-3">
        {/* form */}
        <div className="space-y-5 lg:col-span-2">
          <div className="rounded-3xl border border-slate-100 bg-white p-6">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-black text-ink">
              <span>📍</span> آدرس تحویل
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="نام و نام خانوادگی" required>
                <input
                  required
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  className={inputCls}
                  placeholder="مثلاً علی رضایی"
                />
              </Field>
              <Field label="شماره تماس" required>
                <input
                  required
                  inputMode="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className={inputCls}
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                />
              </Field>
              <Field label="شهر">
                <input
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  className={inputCls}
                  placeholder="تهران"
                />
              </Field>
            </div>
            <div className="mt-4">
              <Field label="آدرس کامل" required>
                <textarea
                  required
                  rows={3}
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  className={`${inputCls} resize-none`}
                  placeholder="خیابان، کوچه، پلاک و واحد"
                />
              </Field>
            </div>
            <div className="mt-4">
              <Field label="یادداشت سفارش (اختیاری)">
                <textarea
                  rows={2}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className={`${inputCls} resize-none`}
                  placeholder="هر توضیحی که لازم است..."
                />
              </Field>
            </div>
          </div>

          {/* payment method */}
          <div className="rounded-3xl border border-slate-100 bg-white p-6">
            <h2 className="mb-4 flex items-center gap-2 text-lg font-black text-ink">
              <span>💳</span> روش پرداخت
            </h2>
            <label className="flex cursor-pointer items-center gap-3 rounded-2xl border-2 border-brand-200 bg-brand-50/50 p-4">
              <span className="grid h-5 w-5 place-items-center rounded-md border-2 border-brand-600 bg-brand-600 text-white">
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="3"><path d="M20 6 9 17l-5-5" /></svg>
              </span>
              <span className="text-sm font-bold text-slate-800">پرداخت در محل (کارتخوان)</span>
              <span className="mr-auto text-xs text-slate-400">رایگان</span>
            </label>
          </div>
        </div>

        {/* summary */}
        <div className="h-fit space-y-4 lg:sticky lg:top-28">
          <div className="rounded-3xl border border-slate-100 bg-white p-6">
            <h2 className="text-lg font-black text-ink">سفارش شما</h2>
            <div className="mt-4 max-h-64 space-y-3 overflow-y-auto pl-1">
              {cart.map((i) => (
                <div key={i.id} className="flex items-center gap-3">
                  <img src={i.image} alt="" className="h-12 w-12 rounded-xl object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold text-slate-700">{i.name}</p>
                    <p className="text-[11px] text-slate-400">{faNum(i.qty)} عدد</p>
                  </div>
                  <span className="text-xs font-bold text-slate-700">
                    {faNum(i.price * i.qty)}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 text-sm">
              <div className="flex justify-between text-slate-500">
                <span>جمع کالاها</span>
                <span className="font-bold text-slate-800">{faNum(cartTotal)} ت</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>ارسال</span>
                <span className={`font-bold ${shipping === 0 ? "text-emerald-600" : ""}`}>
                  {shipping === 0 ? "رایگان" : faNum(shipping) + " ت"}
                </span>
              </div>
              <div className="flex justify-between border-t border-dashed border-slate-200 pt-2">
                <span className="font-black text-ink">مبلغ نهایی</span>
                <span className="text-lg font-black text-brand-700">
                  {faNum(total)} ت
                </span>
              </div>
            </div>
          </div>

          {error && (
            <p className="rounded-xl bg-rose-50 px-4 py-2.5 text-sm text-rose-600">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 py-4 text-sm font-bold text-white shadow-lg shadow-brand-500/30 transition hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "در حال ثبت..." : `ثبت سفارش (${faNum(total)} ت)`}
          </button>
          <p className="text-center text-xs text-slate-400">
            با ثبت سفارش، قوانین فروشگاه را می‌پذیرید.
          </p>
        </div>
      </form>
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm outline-none transition focus:border-brand-400 focus:bg-white";

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-bold text-slate-700">
        {label} {required && <span className="text-rose-500">*</span>}
      </span>
      {children}
    </label>
  );
}
