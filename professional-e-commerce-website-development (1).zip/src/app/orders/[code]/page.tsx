import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { faNum, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";

const steps = [
  { key: "در حال پردازش", label: "ثبت سفارش", icon: "📝" },
  { key: "ارسال شده", label: "ارسال شده", icon: "🚚" },
  { key: "تحویل داده شده", label: "تحویل شده", icon: "✅" },
];

export default async function OrderPage({
  params,
}: {
  params: Promise<{ code: string }>;
}) {
  const { code } = await params;
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.code, code))
    .limit(1);
  const order = rows[0];
  if (!order) notFound();

  const currentStep = steps.findIndex((s) => s.key === order.status);
  const activeStep = currentStep === -1 ? 0 : currentStep;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <Link
        href="/"
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-bold text-slate-500 hover:text-brand-600"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M19 12H5M12 5l-7 7 7 7" /></svg>
        بازگشت
      </Link>

      <div className="overflow-hidden rounded-3xl border border-slate-100 bg-white">
        {/* header */}
        <div className="border-b border-slate-100 bg-gradient-to-l from-brand-50 to-fuchsia-50/50 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs text-slate-500">کد رهگیری</p>
              <p className="text-xl font-black tracking-wider text-brand-700">
                {order.code}
              </p>
            </div>
            <div className="text-left">
              <p className="text-xs text-slate-500">تاریخ ثبت</p>
              <p className="text-sm font-bold text-slate-700">
                {formatDate(order.createdAt)}
              </p>
            </div>
            <span className="rounded-full bg-brand-600 px-4 py-1.5 text-xs font-bold text-white">
              {order.status}
            </span>
          </div>
        </div>

        {/* timeline */}
        <div className="p-6">
          <div className="flex items-center justify-between">
            {steps.map((s, i) => {
              const done = i <= activeStep;
              return (
                <div key={s.key} className="flex flex-1 flex-col items-center">
                  <div className="flex w-full items-center">
                    {i > 0 && (
                      <div
                        className={`h-1 flex-1 ${i <= activeStep ? "bg-brand-500" : "bg-slate-200"}`}
                      />
                    )}
                    <div
                      className={`grid h-11 w-11 shrink-0 place-items-center rounded-full text-lg transition ${
                        done
                          ? "bg-gradient-to-br from-brand-500 to-fuchsia-500 text-white shadow-lg shadow-brand-500/30"
                          : "bg-slate-100 text-slate-400"
                      }`}
                    >
                      {s.icon}
                    </div>
                    {i < steps.length - 1 && (
                      <div
                        className={`h-1 flex-1 ${i < activeStep ? "bg-brand-500" : "bg-slate-200"}`}
                      />
                    )}
                  </div>
                  <span
                    className={`mt-2 text-xs font-bold ${done ? "text-brand-700" : "text-slate-400"}`}
                  >
                    {s.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* items */}
        <div className="border-t border-slate-100 p-6">
          <h2 className="mb-4 text-lg font-black text-ink">اقلام سفارش</h2>
          <div className="space-y-3">
            {order.items?.map((item) => (
              <div key={item.id} className="flex items-center gap-3">
                <img
                  src={item.image}
                  alt={item.name}
                  className="h-14 w-14 rounded-xl object-cover"
                />
                <div className="flex-1">
                  <p className="text-sm font-bold text-slate-800">{item.name}</p>
                  <p className="text-xs text-slate-400">{faNum(item.qty)} عدد</p>
                </div>
                <span className="text-sm font-bold text-slate-700">
                  {faNum(item.price * item.qty)} ت
                </span>
              </div>
            ))}
          </div>

          <div className="mt-5 flex justify-between border-t border-dashed border-slate-200 pt-4">
            <span className="font-black text-ink">مبلغ کل پرداخت‌شده</span>
            <span className="text-lg font-black text-brand-700">
              {faNum(order.total)} تومان
            </span>
          </div>
        </div>

        {/* address */}
        <div className="border-t border-slate-100 bg-slate-50/50 p-6">
          <h2 className="mb-3 text-sm font-black text-ink">آدرس تحویل گیرنده</h2>
          <div className="grid gap-2 text-sm text-slate-600 sm:grid-cols-2">
            <p><span className="text-slate-400">نام:</span> {order.fullName}</p>
            <p><span className="text-slate-400">تلفن:</span> {order.phone}</p>
            {order.city && <p><span className="text-slate-400">شهر:</span> {order.city}</p>}
            <p className="sm:col-span-2"><span className="text-slate-400">آدرس:</span> {order.address}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
