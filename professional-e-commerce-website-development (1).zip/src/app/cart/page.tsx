"use client";

import Link from "next/link";
import { useStore } from "@/components/store-provider";
import { faNum } from "@/lib/format";

export default function CartPage() {
  const { cart, updateQty, removeFromCart, cartTotal, clearCart, freeShipThreshold, shippingFee } = useStore();
  const shipping = cartTotal >= freeShipThreshold || cartTotal === 0 ? 0 : shippingFee;

  if (cart.length === 0) {
    return (
      <div className="mx-auto flex max-w-3xl flex-col items-center gap-5 px-4 py-24 text-center">
        <div className="grid h-28 w-28 place-items-center rounded-full bg-slate-100 text-6xl">
          🛒
        </div>
        <h1 className="text-2xl font-black text-ink">سبد خرید شما خالی است</h1>
        <p className="text-sm text-slate-500">
          هنوز محصولی به سبد اضافه نکرده‌اید.
        </p>
        <Link
          href="/shop"
          className="rounded-2xl bg-ink px-7 py-3.5 text-sm font-bold text-white transition hover:bg-brand-700"
        >
          شروع خرید
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-black text-ink sm:text-3xl">سبد خرید</h1>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* items */}
        <div className="space-y-3 lg:col-span-2">
          {cart.map((item) => (
            <div
              key={item.id}
              className="flex gap-4 rounded-3xl border border-slate-100 bg-white p-4"
            >
              <Link href={`/products/${item.slug}`}>
                <img
                  src={item.image}
                  alt={item.name}
                  className="h-24 w-24 rounded-2xl object-cover sm:h-28 sm:w-28"
                />
              </Link>
              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <Link
                    href={`/products/${item.slug}`}
                    className="text-sm font-bold text-slate-800 hover:text-brand-600 sm:text-base"
                  >
                    {item.name}
                  </Link>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-slate-300 transition hover:text-rose-500"
                    aria-label="حذف"
                  >
                    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6" /></svg>
                  </button>
                </div>
                <span className="mt-1 text-xs text-slate-400">
                  قیمت واحد: {faNum(item.price)} تومان
                </span>
                <div className="mt-auto flex items-center justify-between pt-3">
                  <div className="flex items-center gap-1 rounded-xl border border-slate-200 p-0.5">
                    <button
                      onClick={() => updateQty(item.id, item.qty + 1)}
                      className="grid h-8 w-8 place-items-center rounded-lg text-slate-600 hover:bg-slate-100"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14" /></svg>
                    </button>
                    <span className="w-8 text-center text-sm font-bold">{faNum(item.qty)}</span>
                    <button
                      onClick={() => updateQty(item.id, item.qty - 1)}
                      className="grid h-8 w-8 place-items-center rounded-lg text-slate-600 hover:bg-slate-100"
                    >
                      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14" /></svg>
                    </button>
                  </div>
                  <span className="text-base font-black text-brand-700">
                    {faNum(item.price * item.qty)} ت
                  </span>
                </div>
              </div>
            </div>
          ))}

          <div className="flex items-center justify-between pt-2">
            <Link
              href="/shop"
              className="text-sm font-bold text-brand-600 hover:text-brand-700"
            >
              ← ادامه خرید
            </Link>
            <button
              onClick={clearCart}
              className="text-sm text-slate-400 transition hover:text-rose-500"
            >
              خالی کردن سبد
            </button>
          </div>
        </div>

        {/* summary */}
        <div className="h-fit rounded-3xl border border-slate-100 bg-white p-6 lg:sticky lg:top-28">
          <h2 className="text-lg font-black text-ink">خلاصه سفارش</h2>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between text-slate-500">
              <span>جمع کالاها</span>
              <span className="font-bold text-slate-800">{faNum(cartTotal)} ت</span>
            </div>
            <div className="flex justify-between text-slate-500">
              <span>هزینه ارسال</span>
              <span className={`font-bold ${shipping === 0 ? "text-emerald-600" : "text-slate-800"}`}>
                {shipping === 0 ? "رایگان" : faNum(shipping) + " ت"}
              </span>
            </div>
            {shipping > 0 && (
              <p className="rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-700">
                با {faNum(freeShipThreshold - cartTotal)} تومان خرید بیشتر، ارسال رایگان می‌شود!
              </p>
            )}
            <div className="flex justify-between border-t border-dashed border-slate-200 pt-3">
              <span className="font-black text-ink">مبلغ نهایی</span>
              <span className="text-xl font-black text-brand-700">
                {faNum(cartTotal + shipping)} ت
              </span>
            </div>
          </div>
          <Link
            href="/checkout"
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand-500/30 transition hover:opacity-90"
          >
            ادامه و پرداخت
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M19 12H5M12 5l-7 7 7 7" /></svg>
          </Link>
          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-400">
            🛡️ پرداخت امن و رمزنگاری‌شده
          </div>
        </div>
      </div>
    </div>
  );
}
