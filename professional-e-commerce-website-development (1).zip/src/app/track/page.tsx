"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function TrackPage() {
  const router = useRouter();
  const [code, setCode] = useState("");

  return (
    <div className="mx-auto flex max-w-xl flex-col items-center gap-6 px-4 py-20 text-center">
      <div className="grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-brand-500 to-fuchsia-500 text-4xl shadow-lg shadow-brand-500/30">
        📦
      </div>
      <div>
        <h1 className="text-2xl font-black text-ink sm:text-3xl">پیگیری سفارش</h1>
        <p className="mt-2 text-sm text-slate-500">
          کد رهگیری سفارش خود را وارد کنید تا وضعیت آن را ببینید.
        </p>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (code.trim()) router.push(`/orders/${code.trim()}`);
        }}
        className="flex w-full flex-col gap-3 sm:flex-row"
      >
        <input
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="مثلاً LU-123456ABCD"
          className="flex-1 rounded-2xl border border-slate-200 bg-white px-5 py-3.5 text-center text-sm font-bold tracking-wider outline-none transition focus:border-brand-400 focus:ring-4 focus:ring-brand-100"
        />
        <button
          type="submit"
          className="rounded-2xl bg-ink px-7 py-3.5 text-sm font-bold text-white transition hover:bg-brand-700"
        >
          پیگیری
        </button>
      </form>

      <p className="text-xs text-slate-400">
        💡 کد رهگیری پس از ثبت سفارش به شما نمایش داده می‌شود.
      </p>
    </div>
  );
}
