import { NextRequest, NextResponse } from "next/server";
import { ADMIN_PASSWORD, isLoggedIn, setAdminCookie } from "@/lib/admin";

export async function GET() {
  const ok = await isLoggedIn();
  return NextResponse.json({ authenticated: ok });
}

export async function POST(req: NextRequest) {
  const { password } = await req.json();
  if (password !== ADMIN_PASSWORD) {
    return NextResponse.json({ error: "رمز عبور اشتباه است" }, { status: 401 });
  }
  await setAdminCookie();
  return NextResponse.json({ ok: true });
}
