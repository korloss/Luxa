import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { desc, eq } from "drizzle-orm";

function slugify(s: string) {
  return s
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\u0600-\u06FFa-zA-Z0-9-]/g, "")
    .toLowerCase();
}

export async function GET() {
  const guard = await apiGuard();
  if (guard) return guard;
  const rows = await db.select().from(products).orderBy(desc(products.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const guard = await apiGuard();
  if (guard) return guard;
  const b = await req.json();

  const name = String(b.name || "").trim();
  if (!name) return NextResponse.json({ error: "نام محصول الزامی است" }, { status: 400 });

  const slug = String(b.slug || slugify(name));
  const row = {
    name,
    slug,
    description: String(b.description || ""),
    brand: b.brand ? String(b.brand) : null,
    price: Number(b.price) || 0,
    oldPrice: b.oldPrice ? Number(b.oldPrice) : null,
    image: String(b.image || ""),
    gallery: Array.isArray(b.gallery) ? b.gallery : [],
    specs: Array.isArray(b.specs) ? b.specs : [],
    rating: Number(b.rating) || 0,
    reviewCount: Number(b.reviewCount) || 0,
    stock: Number(b.stock) || 0,
    badge: b.badge ? String(b.badge) : null,
    categoryId: b.categoryId ? Number(b.categoryId) : null,
    featured: !!b.featured,
    department: String(b.department || "tech"),
  };

  const [created] = await db.insert(products).values(row).returning();
  return NextResponse.json(created);
}
