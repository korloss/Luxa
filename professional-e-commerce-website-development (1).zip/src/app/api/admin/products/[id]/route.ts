import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  const b = await req.json();

  const updates: Record<string, unknown> = {};
  const map: Record<string, (v: unknown) => unknown> = {
    name: (v) => String(v),
    slug: (v) => String(v),
    description: (v) => String(v),
    brand: (v) => (v ? String(v) : null),
    price: (v) => Number(v),
    oldPrice: (v) => (v ? Number(v) : null),
    image: (v) => String(v),
    gallery: (v) => (Array.isArray(v) ? v : []),
    specs: (v) => (Array.isArray(v) ? v : []),
    rating: (v) => Number(v),
    reviewCount: (v) => Number(v),
    stock: (v) => Number(v),
    badge: (v) => (v ? String(v) : null),
    categoryId: (v) => (v ? Number(v) : null),
    featured: (v) => !!v,
    department: (v) => String(v),
  };
  for (const key of Object.keys(map)) {
    if (key in b) updates[key] = map[key](b[key]);
  }

  const [updated] = await db
    .update(products)
    .set(updates)
    .where(eq(products.id, Number(id)))
    .returning();
  if (!updated) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  await db.delete(products).where(eq(products.id, Number(id)));
  return NextResponse.json({ ok: true });
}
