import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { media } from "@/db/schema";
import { apiGuard } from "@/lib/admin";

// تبدیل فایل به data URL (base64) برای ذخیره در دیتابیس
// این روش روی همه‌ی پلتفرم‌ها (Netlify، Vercel و ...) کار می‌کند چون نیازی به
// نوشتن در فایل‌سیستم ندارد و داده‌ها در دیتابیس ماندگار می‌شوند.
async function fileToDataUrl(file: File): Promise<string> {
  const buffer = Buffer.from(await file.arrayBuffer());
  const mime = file.type || "image/jpeg";
  const base64 = buffer.toString("base64");
  return `data:${mime};base64,${base64}`;
}

export async function POST(req: NextRequest) {
  const guard = await apiGuard();
  if (guard) return guard;

  const formData = await req.formData();
  const file = formData.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "فایلی ارسال نشده" }, { status: 400 });
  }

  // محدودیت حجم: ۸۰۰ کیلوبایت (data URL حدود ۱.۱ مگابایت می‌شود)
  if (file.size > 800 * 1024) {
    return NextResponse.json(
      { error: "حجم فایل باید کمتر از ۸۰۰ کیلوبایت باشد" },
      { status: 400 },
    );
  }

  const allowed = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"];
  if (!allowed.includes(file.type)) {
    return NextResponse.json(
      { error: "فقط فرمت‌های تصویری (JPG, PNG, WEBP, GIF) مجاز هستند" },
      { status: 400 },
    );
  }

  try {
    const dataUrl = await fileToDataUrl(file);
    const [row] = await db
      .insert(media)
      .values({ url: dataUrl, name: file.name })
      .returning();
    return NextResponse.json(row);
  } catch {
    return NextResponse.json({ error: "خطا در پردازش تصویر" }, { status: 500 });
  }
}
