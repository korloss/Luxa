import { NextResponse } from "next/server";
import { db } from "@/db";
import { media } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { desc } from "drizzle-orm";

export async function GET() {
  const guard = await apiGuard();
  if (guard) return guard;
  const rows = await db.select().from(media).orderBy(desc(media.createdAt));
  return NextResponse.json(rows);
}
