import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { media } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { eq } from "drizzle-orm";

// رسانه‌ها به‌صورت data URL در دیتابیس ذخیره می‌شوند، بنابراین برای حذف
// فقط ردیف دیتابیس را پاک می‌کنیم (نیازی به حذف فایل فیزیکی نیست).
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;

  const rows = await db.select().from(media).where(eq(media.id, Number(id))).limit(1);
  if (!rows[0]) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });

  await db.delete(media).where(eq(media.id, Number(id)));
  return NextResponse.json({ ok: true });
}
