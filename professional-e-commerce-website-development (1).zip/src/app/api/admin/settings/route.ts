import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { eq } from "drizzle-orm";

export async function GET() {
  const guard = await apiGuard();
  if (guard) return guard;
  const rows = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  return NextResponse.json(rows[0] ?? null);
}

const ALLOWED = [
  "heroBadge", "heroTitle", "heroHighlight", "heroSubtitle",
  "announcementText", "primaryColor", "accentColor",
  "contactPhone", "contactEmail", "contactAddress",
] as const;

export async function PUT(req: NextRequest) {
  const guard = await apiGuard();
  if (guard) return guard;
  const b = await req.json();
  const updates: Record<string, unknown> = {};
  for (const key of ALLOWED) {
    if (key in b) updates[key] = String(b[key]);
  }
  if (typeof b.freeShipThreshold === "number") updates.freeShipThreshold = b.freeShipThreshold;
  if (typeof b.shippingFee === "number") updates.shippingFee = b.shippingFee;
  if (typeof b.showFood === "boolean") updates.showFood = b.showFood;

  const [updated] = await db.update(settings).set(updates).where(eq(settings.id, 1)).returning();
  if (!updated) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  return NextResponse.json(updated);
}
