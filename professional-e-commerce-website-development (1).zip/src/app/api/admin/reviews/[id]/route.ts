import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { eq } from "drizzle-orm";

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  await db.delete(reviews).where(eq(reviews.id, Number(id)));
  return NextResponse.json({ ok: true });
}
