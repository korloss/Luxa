import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { eq } from "drizzle-orm";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  const { status } = await req.json();
  const [updated] = await db
    .update(orders)
    .set({ status: String(status) })
    .where(eq(orders.id, Number(id)))
    .returning();
  if (!updated) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  await db.delete(orders).where(eq(orders.id, Number(id)));
  return NextResponse.json({ ok: true });
}
