import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { asc } from "drizzle-orm";

function slugify(s: string) {
  return s.trim().replace(/\s+/g, "-").replace(/[^\u0600-\u06FFa-zA-Z0-9-]/g, "").toLowerCase();
}

export async function GET() {
  const guard = await apiGuard();
  if (guard) return guard;
  const rows = await db.select().from(categories).orderBy(asc(categories.id));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const guard = await apiGuard();
  if (guard) return guard;
  const b = await req.json();
  const name = String(b.name || "").trim();
  if (!name) return NextResponse.json({ error: "نام الزامی است" }, { status: 400 });
  const row = {
    name,
    slug: String(b.slug || slugify(name)),
    icon: b.icon ? String(b.icon) : null,
    color: b.color ? String(b.color) : "from-brand-500 to-fuchsia-500",
    description: b.description ? String(b.description) : null,
    department: String(b.department || "tech"),
  };
  const [created] = await db.insert(categories).values(row).returning();
  return NextResponse.json(created);
}
