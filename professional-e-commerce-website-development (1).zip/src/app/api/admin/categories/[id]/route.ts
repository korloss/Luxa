import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { apiGuard } from "@/lib/admin";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  const b = await req.json();
  const updates: Record<string, unknown> = {};
  for (const key of ["name", "slug", "icon", "color", "description", "department"]) {
    if (key in b) updates[key] = b[key] === "" || b[key] === null ? null : String(b[key]);
  }
  const [updated] = await db.update(categories).set(updates).where(eq(categories.id, Number(id))).returning();
  if (!updated) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const guard = await apiGuard();
  if (guard) return guard;
  const { id } = await params;
  await db.delete(categories).where(eq(categories.id, Number(id)));
  return NextResponse.json({ ok: true });
}
