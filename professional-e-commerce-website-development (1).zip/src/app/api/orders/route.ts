import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

type OrderItem = {
  id: number;
  name: string;
  price: number;
  qty: number;
  image: string;
};

function genCode() {
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `LU-${Date.now().toString().slice(-6)}${rand}`;
}

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code")?.trim();
  if (!code) return NextResponse.json({ error: "کد لازم است" }, { status: 400 });
  const rows = await db.select().from(orders).where(eq(orders.code, code)).limit(1);
  if (!rows[0]) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  return NextResponse.json(rows[0]);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const fullName = String(body.fullName || "").trim().slice(0, 80);
    const phone = String(body.phone || "").trim().slice(0, 20);
    const address = String(body.address || "").trim().slice(0, 500);
    const city = String(body.city || "").trim().slice(0, 60);
    const notes = String(body.notes || "").trim().slice(0, 500);
    const items: OrderItem[] = Array.isArray(body.items) ? body.items : [];

    if (!fullName || !phone || !address || items.length === 0) {
      return NextResponse.json(
        { error: "اطلاعات سفارش ناقص است" },
        { status: 400 },
      );
    }

    const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
    const shipping = subtotal >= 5000000 ? 0 : 250000;
    const total = subtotal + shipping;
    const code = genCode();

    const [order] = await db
      .insert(orders)
      .values({
        code,
        fullName,
        phone,
        address,
        city: city || null,
        notes: notes || null,
        total,
        items,
      })
      .returning();

    return NextResponse.json({ code, order });
  } catch {
    return NextResponse.json({ error: "خطای سرور" }, { status: 500 });
  }
}
