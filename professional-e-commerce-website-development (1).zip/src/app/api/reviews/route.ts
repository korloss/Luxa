import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, products } from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const productId = Number(req.nextUrl.searchParams.get("productId"));
  if (!productId || Number.isNaN(productId)) return NextResponse.json([]);
  const rows = await db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const productId = Number(body.productId);
    const name = String(body.name || "").trim().slice(0, 60);
    const rating = Math.min(5, Math.max(1, Number(body.rating) || 5));
    const comment = String(body.comment || "").trim().slice(0, 1000);

    if (!productId || !name || !comment) {
      return NextResponse.json(
        { error: "اطلاعات ناقص است" },
        { status: 400 },
      );
    }

    const [created] = await db
      .insert(reviews)
      .values({ productId, name, rating, comment })
      .returning();

    const [agg] = await db
      .select({
        avg: sql<number>`coalesce(avg(${reviews.rating}), 0)`,
        cnt: sql<number>`count(*)::int`,
      })
      .from(reviews)
      .where(eq(reviews.productId, productId));

    await db
      .update(products)
      .set({
        rating: Math.round(Number(agg.avg) * 10) / 10,
        reviewCount: Number(agg.cnt),
      })
      .where(eq(products.id, productId));

    return NextResponse.json(created);
  } catch {
    return NextResponse.json({ error: "خطای سرور" }, { status: 500 });
  }
}
