import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-xl flex-col items-center gap-6 px-4 py-28 text-center">
      <div className="text-8xl">🧭</div>
      <h1 className="text-3xl font-black text-ink">صفحه‌ای پیدا نشد</h1>
      <p className="text-sm text-slate-500">
        متأسفانه صفحه‌ای که دنبال آن بودید وجود ندارد یا جابه‌جا شده است.
      </p>
      <Link
        href="/"
        className="rounded-2xl bg-ink px-7 py-3.5 text-sm font-bold text-white transition hover:bg-brand-700"
      >
        بازگشت به خانه
      </Link>
    </div>
  );
}
