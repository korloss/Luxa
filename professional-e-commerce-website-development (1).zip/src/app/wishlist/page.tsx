import { WishlistClient } from "@/components/wishlist-client";
import { getAllProducts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function WishlistPage() {
  const products = await getAllProducts();
  return <WishlistClient products={products} />;
}
