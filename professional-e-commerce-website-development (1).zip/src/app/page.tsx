import Link from "next/link";
import { ProductCard } from "@/components/product-card";
import {
  getAllCategories,
  getFeaturedByDepartment,
  getAllProducts,
  getCategoriesByDepartment,
  getSettings,
} from "@/lib/queries";
import { faNum, discountPercent } from "@/lib/format";

export const dynamic = "force-dynamic";

const features = [
  { icon: "🔍", title: "جستجوی هوشمند", desc: "پیدا کردن سریع محصول دلخواه" },
  { icon: "🎚️", title: "فیلتر و مرتب‌سازی", desc: "صافی پیشرفته بر اساس قیمت و امتیاز" },
  { icon: "🛒", title: "سبد خرید پویا", desc: "مدیریت لحظه‌ای سبد با انیمیشن" },
  { icon: "❤️", title: "لیست علاقه‌مندی‌ها", desc: "ذخیره محصولات محبوب شما" },
  { icon: "⭐", title: "امتیاز و نظرات", desc: "تجربه واقعی خریداران" },
  { icon: "📦", title: "جزئیات کامل محصول", desc: "مشخصات، گالری و توضیحات" },
  { icon: "⚡", title: "تسویه حساب سریع", desc: "خرید امن در چند ثانیه" },
  { icon: "🚚", title: "پیگیری سفارش", desc: "وضعیت لحظه‌ای ارسال" },
  { icon: "🗂️", title: "دو فروشگاه در یک‌جا", desc: "دیجیتال و مواد غذایی" },
  { icon: "📱", title: "طراحی واکنش‌گرا", desc: "تجربه‌ای بی‌نقص روی همه دستگاه‌ها" },
];

const testimonials = [
  { name: "نیلوفر ک.", text: "سریع‌ترین ارسالی که تا حالا تجربه کردم. بسته‌بندی عالی و محصول کاملاً اصل بود.", role: "خریدار گوشی" },
  { name: "محمد ر.", text: "پشتیبانی فوق‌العاده و قیمت منصفانه. حتماً دوباره از لوکسا خرید می‌کنم.", role: "خریدار لپ‌تاپ" },
  { name: "زهرا م.", text: "میوه‌ها و لبنیات همیشه تازه‌اند. سوپرمارکت آنلاین لوکسا واقعاً به کارم میاد.", role: "خریدار مواد غذایی" },
];

export default async function HomePage() {
  const [settings, categories, techFeatured, foodFeatured, foodCats, all] =
    await Promise.all([
      getSettings(),
      getAllCategories(),
      getFeaturedByDepartment("tech", 8),
      getFeaturedByDepartment("food", 8),
      getCategoriesByDepartment("food"),
      getAllProducts(),
    ]);
  const showFood = settings?.showFood ?? true;
  const discounted = all.filter((p) => p.oldPrice && p.oldPrice > p.price);

  return (
    <div className="overflow-hidden">
      {/* ===================== HERO ===================== */}
      <section className="relative bg-ink text-white">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-brand-600/40 blur-[120px]" />
          <div className="absolute -left-20 top-40 h-80 w-80 rounded-full bg-fuchsia-600/30 blur-[120px]" />
          <div className="absolute bottom-0 right-1/3 h-72 w-72 rounded-full bg-indigo-500/20 blur-[100px]" />
        </div>

        <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 lg:grid-cols-2 lg:py-24">
          <div className="animate-fade-up text-center lg:text-right">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-medium text-brand-200">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-400" />
              {settings?.heroBadge ?? "جشنواره فروش پاییزه آغاز شد"}
            </span>
            <h1 className="mt-6 text-4xl font-black leading-tight text-balance sm:text-5xl lg:text-6xl">
              {settings?.heroTitle ?? "دنیای"}{" "}
              <span className="gradient-text">{settings?.heroHighlight ?? "تکنولوژی"}</span>
            </h1>
            <p className="mx-auto mt-5 max-w-lg text-base leading-8 text-slate-300 lg:mx-0">
              {settings?.heroSubtitle ??
                "جدیدترین موبایل، لپ‌تاپ، هدفون و گجت‌های هوشمند را با ضمانت اصالت کالا از لوکسا خرید کنید."}
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
              <Link href="/shop?dept=tech" className="group flex items-center gap-2 rounded-2xl bg-gradient-to-l from-brand-500 to-fuchsia-500 px-7 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-500/30 transition hover:scale-105">
                💻 فروشگاه دیجیتال
              </Link>
              <Link href="/shop?dept=food" className="rounded-2xl border border-white/15 bg-white/5 px-7 py-3.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/10">
                🛒 سوپرمارکت
              </Link>
            </div>
            <div className="mt-10 flex items-center justify-center gap-8 lg:justify-start">
              {[{ n: "+۵۰هزار", l: "مشتری راضی" }, { n: "+۲۰۰۰", l: "محصول اصل" }, { n: "۴.۸★", l: "امتیاز فروشگاه" }].map((s) => (
                <div key={s.l} className="text-center lg:text-right">
                  <div className="text-2xl font-black text-white">{s.n}</div>
                  <div className="text-xs text-slate-400">{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* visual */}
          <div className="relative mx-auto hidden h-[420px] w-full max-w-md lg:block">
            <div className="absolute left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 animate-spin-slow rounded-full border border-dashed border-white/10" />
            <div className="absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-brand-500/30 to-fuchsia-500/20 blur-2xl" />
            <div className="animate-float absolute right-4 top-8 w-48 rotate-3 rounded-3xl border border-white/10 bg-white p-3 shadow-2xl">
              <img src="https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="هدفون" className="aspect-square w-full rounded-2xl object-cover" />
              <div className="mt-2 text-right">
                <p className="text-xs font-bold text-slate-800">هدفون ایرو ANC</p>
                <p className="text-xs font-black text-brand-600">۸٫۹۰۰٫۰۰۰ ت</p>
              </div>
            </div>
            <div className="animate-float-slow absolute bottom-6 left-2 w-44 -rotate-6 rounded-3xl border border-white/10 bg-white p-3 shadow-2xl">
              <img src="https://images.pexels.com/photos/18258533/pexels-photo-18258533.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="شیر" className="aspect-square w-full rounded-2xl object-cover" />
              <div className="mt-2 text-right">
                <p className="text-xs font-bold text-slate-800">شیر تازه پاستوریزه</p>
                <p className="text-xs font-black text-brand-600">۹۵٫۰۰۰ ت</p>
              </div>
            </div>
            <div className="animate-pop absolute bottom-24 right-0 flex items-center gap-2 rounded-2xl bg-white px-4 py-3 shadow-xl">
              <span className="text-2xl">🚚</span>
              <div className="text-right">
                <p className="text-xs font-black text-slate-800">ارسال رایگان</p>
                <p className="text-[10px] text-slate-500">همین امروز ثبت شود</p>
              </div>
            </div>
          </div>
        </div>

        <div className="relative">
          <svg viewBox="0 0 1440 60" className="block h-8 w-full sm:h-12" preserveAspectRatio="none">
            <path d="M0,32 C360,72 1080,0 1440,40 L1440,60 L0,60 Z" className="fill-slate-50" />
          </svg>
        </div>
      </section>

      {/* ===================== CATEGORY SHOPCARDS ===================== */}
      <section className="mx-auto max-w-7xl px-4 py-10">
        <div className="grid gap-5 md:grid-cols-2">
          <Link href="/shop?dept=tech" className="group relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 to-brand-700 p-8 text-white transition hover:scale-[1.02]">
            <div className="absolute -left-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
            <p className="text-sm font-medium text-brand-100">فروشگاه دیجیتال</p>
            <h3 className="mt-2 text-2xl font-black">کالای دیجیتال و گجت</h3>
            <p className="mt-2 max-w-xs text-sm text-brand-100">موبایل، لپ‌تاپ، هدفون، ساعت و دوربین</p>
            <span className="mt-4 inline-block text-sm font-bold">مشاهده ←</span>
            <span className="absolute bottom-4 left-6 text-6xl opacity-25">💻</span>
          </Link>
          <Link href="/shop?dept=food" className="group relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 p-8 text-white transition hover:scale-[1.02]">
            <div className="absolute -left-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
            <p className="text-sm font-medium text-emerald-100">سوپرمارکت آنلاین</p>
            <h3 className="mt-2 text-2xl font-black">مواد غذایی و خوراک</h3>
            <p className="mt-2 max-w-xs text-sm text-emerald-100">میوه، لبنیات، پروتئین، نان و نوشیدنی</p>
            <span className="mt-4 inline-block text-sm font-bold">مشاهده ←</span>
            <span className="absolute bottom-4 left-6 text-6xl opacity-25">🛒</span>
          </Link>
        </div>
      </section>

      {/* ===================== TECH FEATURED ===================== */}
      <section className="mx-auto max-w-7xl px-4 py-10">
        <SectionHeader eyebrow="دیجیتال" title="محبوب‌ترین‌های کالای دیجیتال" action={{ href: "/shop?dept=tech", label: "مشاهده همه" }} />
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {techFeatured.slice(0, 8).map((p) => (<ProductCard key={p.id} product={p} />))}
        </div>
      </section>

      {/* ===================== FOOD FEATURED ===================== */}
      {showFood && (
        <section className="bg-emerald-50/40 py-10">
          <div className="mx-auto max-w-7xl px-4">
            <SectionHeader eyebrow="🛒 سوپرمارکت" title="مواد غذایی تازه" action={{ href: "/shop?dept=food", label: "مشاهده همه" }} />
            <div className="mt-6 grid grid-cols-3 gap-3 sm:grid-cols-6">
              {foodCats.map((c) => (
                <Link key={c.id} href={`/shop?cat=${c.slug}&dept=food`} className="group flex flex-col items-center gap-2 rounded-2xl border border-emerald-100 bg-white p-4 text-center transition hover:-translate-y-1 hover:shadow-lg">
                  <span className={`grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${c.color} text-2xl`}>{c.icon}</span>
                  <span className="text-xs font-bold text-slate-700">{c.name}</span>
                </Link>
              ))}
            </div>
            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {foodFeatured.slice(0, 4).map((p) => (<ProductCard key={p.id} product={p} />))}
            </div>
          </div>
        </section>
      )}

      {/* ===================== DISCOUNTED ===================== */}
      {discounted.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-10">
          <SectionHeader eyebrow="⏳ فرصت محدود" title="فرصت طلایی تخفیف" action={{ href: "/shop?sort=discount", label: "همه تخفیف‌ها" }} />
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {discounted.slice(0, 4).map((p) => (<ProductCard key={p.id} product={p} />))}
          </div>
        </section>
      )}

      {/* ===================== FEATURES (10) ===================== */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHeader eyebrow="چرا لوکسا؟" title="۱۰ قابلیت حرفه‌ای فروشگاه" center />
          <p className="mx-auto mt-3 max-w-2xl text-center text-sm text-slate-500">
            تجربه‌ای کامل و مدرن از خرید آنلاین، با امکاناتی که خرید را ساده و لذت‌بخش می‌کنند.
          </p>
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {features.map((f, i) => (
              <div key={f.title} className="group relative flex flex-col items-center gap-3 rounded-3xl border border-slate-100 bg-slate-50/50 p-5 text-center transition-all hover:border-brand-200 hover:bg-white hover:shadow-lg">
                <span className="absolute right-3 top-3 text-xs font-black text-slate-200">{faNum(i + 1)}</span>
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-500/10 to-fuchsia-500/10 text-3xl transition-transform group-hover:scale-110">{f.icon}</span>
                <span className="text-sm font-bold text-slate-800">{f.title}</span>
                <span className="text-xs leading-5 text-slate-500">{f.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===================== TESTIMONIALS ===================== */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <SectionHeader eyebrow="نظرات مشتریان" title="تجربه خریداران ما" center />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="flex flex-col gap-4 rounded-3xl border border-slate-100 bg-white p-6 shadow-sm">
              <div className="flex gap-0.5 text-amber-400" dir="ltr">{"★★★★★".split("").map((s, i) => (<span key={i}>{s}</span>))}</div>
              <p className="text-sm leading-7 text-slate-600">“{t.text}”</p>
              <div className="mt-auto flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-fuchsia-500 font-bold text-white">{t.name.charAt(0)}</span>
                <div>
                  <p className="text-sm font-bold text-slate-800">{t.name}</p>
                  <p className="text-xs text-slate-400">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ===================== CTA ===================== */}
      <section className="mx-auto max-w-7xl px-4 pb-8">
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-l from-brand-700 via-brand-600 to-fuchsia-600 px-8 py-14 text-center text-white">
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
            <div className="absolute -bottom-16 -left-16 h-64 w-64 rounded-full bg-fuchsia-300/20 blur-3xl" />
          </div>
          <h2 className="relative text-3xl font-black sm:text-4xl">آماده‌اید خریدی هوشمندانه داشته باشید؟</h2>
          <p className="relative mx-auto mt-3 max-w-xl text-brand-100">همین حالا به فروشگاه لوکسا بپیوندید و از تخفیف‌های ویژه بهره‌مند شوید.</p>
          <Link href="/shop" className="relative mt-7 inline-flex items-center gap-2 rounded-2xl bg-white px-8 py-3.5 text-sm font-bold text-brand-700 shadow-xl transition hover:scale-105">شروع خرید</Link>
        </div>
      </section>
    </div>
  );
}

function SectionHeader({ eyebrow, title, action, center }: { eyebrow: string; title: string; action?: { href: string; label: string }; center?: boolean }) {
  return (
    <div className={`flex items-end justify-between gap-4 ${center ? "flex-col items-center text-center" : ""}`}>
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-brand-600">{eyebrow}</span>
        <h2 className="mt-1.5 text-2xl font-black text-ink sm:text-3xl">{title}</h2>
      </div>
      {action && (
        <Link href={action.href} className="group flex shrink-0 items-center gap-1.5 text-sm font-bold text-brand-600 hover:text-brand-700">
          {action.label}
          <svg viewBox="0 0 24 24" className="h-4 w-4 transition group-hover:-translate-x-1" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M19 12H5M12 5l-7 7 7 7" /></svg>
        </Link>
      )}
    </div>
  );
}
