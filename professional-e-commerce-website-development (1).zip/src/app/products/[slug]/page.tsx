import { notFound } from "next/navigation";
import { ProductDetail } from "@/components/product-detail";
import {
  getProductBySlug,
  getRelatedProducts,
  getProductReviews,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [related, reviews] = await Promise.all([
    getRelatedProducts(product.categoryId ?? 0, product.id, 4),
    getProductReviews(product.id),
  ]);

  return <ProductDetail product={product} related={related} initialReviews={reviews} />;
}
