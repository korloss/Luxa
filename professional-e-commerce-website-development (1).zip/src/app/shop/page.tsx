import { ShopClient } from "@/components/shop-client";
import { getAllProducts, getAllCategories } from "@/lib/queries";
import { DEPARTMENTS } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; cat?: string; sort?: string; dept?: string }>;
}) {
  const params = await searchParams;
  const dept = params.dept || "tech";
  const [products, categories] = await Promise.all([
    getAllProducts(),
    getAllCategories(),
  ]);

  const deptInfo = DEPARTMENTS.find((d) => d.id === dept);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="mb-2 flex items-center gap-2">
        <span className="text-2xl">{deptInfo?.icon ?? "🛍️"}</span>
        <div>
          <h1 className="text-2xl font-black text-ink sm:text-3xl">
            فروشگاه {deptInfo?.name ?? "لوکسا"}
          </h1>
        </div>
      </div>
      <p className="mb-6 text-sm text-slate-500">
        {products.filter((p) => p.department === dept).length} محصول اصل، آماده ارسال
      </p>
      <ShopClient
        products={products}
        categories={categories}
        initialQuery={params.q ?? ""}
        initialCat={params.cat ?? ""}
        initialSort={params.sort ?? ""}
        initialDept={dept}
      />
    </div>
  );
}
