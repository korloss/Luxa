"use client";

import Link from "next/link";
import { useStore } from "@/components/store-provider";
import { StarRating } from "@/components/star-rating";
import { faNum, discountPercent } from "@/lib/format";
import type { Product } from "@/db/schema";

export function ProductCard({ product }: { product: Product }) {
  const { addToCart, toggleWishlist, inWishlist } = useStore();
  const off = discountPercent(product.price, product.oldPrice);
  const liked = inWishlist(product.id);

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-[0_2px_20px_rgba(16,24,40,0.04)] transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-200 hover:shadow-[0_24px_50px_rgba(124,58,237,0.18)]">
      {/* image */}
      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-slate-50 to-slate-100">
        <Link href={`/products/${product.slug}`}>
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        </Link>

        {/* badges */}
        <div className="absolute right-3 top-3 flex flex-col gap-1.5">
          {product.badge && (
            <span className="rounded-full bg-brand-600 px-2.5 py-1 text-[11px] font-bold text-white shadow-lg">
              {product.badge}
            </span>
          )}
          {off > 0 && (
            <span className="rounded-full bg-rose-500 px-2.5 py-1 text-[11px] font-bold text-white shadow-lg">
              {faNum(off)}٪ تخفیف
            </span>
          )}
        </div>

        {/* wishlist */}
        <button
          onClick={() => toggleWishlist(product.id)}
          aria-label="افزودن به علاقه‌مندی"
          className={`absolute left-3 top-3 grid h-9 w-9 place-items-center rounded-full shadow-lg transition-all duration-300 ${
            liked
              ? "bg-rose-500 text-white"
              : "bg-white/90 text-slate-500 hover:bg-white hover:text-rose-500"
          }`}
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill={liked ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2">
            <path d="M12 21s-7.5-4.6-10-9.3C.6 8.4 2.2 5 5.5 5c2 0 3.3 1.1 4.5 2.7C11.2 6.1 12.5 5 14.5 5 17.8 5 19.4 8.4 18 11.7 15.5 16.4 12 21 12 21z" />
          </svg>
        </button>

        {/* quick add */}
        <div className="absolute inset-x-3 bottom-3 translate-y-[130%] opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <button
            onClick={() =>
              addToCart({
                id: product.id,
                slug: product.slug,
                name: product.name,
                price: product.price,
                image: product.image,
              })
            }
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-ink/90 py-2.5 text-sm font-bold text-white backdrop-blur transition hover:bg-brand-600"
          >
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2">
              <circle cx="9" cy="21" r="1" />
              <circle cx="20" cy="21" r="1" />
              <path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6" />
            </svg>
            افزودن سریع
          </button>
        </div>
      </div>

      {/* body */}
      <div className="flex flex-1 flex-col p-4">
        <span className="text-[11px] font-medium text-slate-400">
          {product.brand}
        </span>
        <Link
          href={`/products/${product.slug}`}
          className="mt-0.5 line-clamp-2 text-sm font-bold leading-6 text-slate-800 transition hover:text-brand-600"
        >
          {product.name}
        </Link>

        <div className="mt-2 flex items-center gap-1.5">
          <StarRating rating={product.rating} />
          <span className="text-[11px] text-slate-400">
            ({faNum(product.reviewCount)})
          </span>
        </div>

        <div className="mt-auto pt-3">
          <div className="flex items-end gap-2">
            <span className="text-base font-extrabold text-slate-900">
              {faNum(product.price)}
            </span>
            <span className="mb-0.5 text-[11px] font-medium text-slate-400">
              تومان
            </span>
          </div>
          {product.oldPrice && product.oldPrice > product.price && (
            <span className="text-xs text-slate-400 line-through">
              {faNum(product.oldPrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
