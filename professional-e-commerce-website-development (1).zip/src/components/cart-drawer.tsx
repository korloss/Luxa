"use client";

import Link from "next/link";
import { useStore } from "@/components/store-provider";
import { faNum } from "@/lib/format";

export function CartDrawer() {
  const {
    cart,
    cartOpen,
    setCartOpen,
    updateQty,
    removeFromCart,
    cartTotal,
    cartCount,
    freeShipThreshold,
    shippingFee,
  } = useStore();

  const shipping = cartTotal >= freeShipThreshold || cartTotal === 0 ? 0 : shippingFee;

  return (
    <div
      className={`fixed inset-0 z-50 ${cartOpen ? "" : "pointer-events-none"}`}
      aria-hidden={!cartOpen}
    >
      {/* overlay */}
      <div
        onClick={() => setCartOpen(false)}
        className={`absolute inset-0 bg-ink/50 backdrop-blur-sm transition-opacity duration-300 ${
          cartOpen ? "opacity-100" : "opacity-0"
        }`}
      />

      {/* panel */}
      <aside
        className={`absolute left-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl transition-transform duration-300 ${
          cartOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* header */}
        <div className="flex items-center justify-between border-b border-slate-100 p-5">
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-brand-600" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="9" cy="21" r="1" />
              <circle cx="20" cy="21" r="1" />
              <path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6" />
            </svg>
            <h2 className="text-lg font-black text-ink">
              سبد خرید {cartCount > 0 && `(${faNum(cartCount)})`}
            </h2>
          </div>
          <button
            onClick={() => setCartOpen(false)}
            className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-slate-600"
            aria-label="بستن"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* items */}
        {cart.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="grid h-24 w-24 place-items-center rounded-full bg-slate-100 text-5xl">
              🛒
            </div>
            <div>
              <p className="text-lg font-bold text-slate-800">سبد شما خالی است</p>
              <p className="mt-1 text-sm text-slate-500">
                محصولات مورد علاقه را اضافه کنید
              </p>
            </div>
            <Link
              href="/shop"
              onClick={() => setCartOpen(false)}
              className="rounded-2xl bg-ink px-6 py-3 text-sm font-bold text-white transition hover:bg-brand-700"
            >
              مشاهده فروشگاه
            </Link>
          </div>
        ) : (
          <>
            <div className="flex-1 space-y-3 overflow-y-auto p-5">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 rounded-2xl border border-slate-100 p-2.5"
                >
                  <Link
                    href={`/products/${item.slug}`}
                    onClick={() => setCartOpen(false)}
                    className="shrink-0"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="h-20 w-20 rounded-xl object-cover"
                    />
                  </Link>
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <p className="line-clamp-2 text-sm font-bold text-slate-800">
                        {item.name}
                      </p>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="shrink-0 text-slate-300 transition hover:text-rose-500"
                        aria-label="حذف"
                      >
                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6" />
                        </svg>
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="flex items-center gap-1 rounded-xl border border-slate-200 p-0.5">
                        <button
                          onClick={() => updateQty(item.id, item.qty + 1)}
                          className="grid h-7 w-7 place-items-center rounded-lg text-slate-600 hover:bg-slate-100"
                        >
                          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M12 5v14M5 12h14" />
                          </svg>
                        </button>
                        <span className="w-6 text-center text-sm font-bold">
                          {faNum(item.qty)}
                        </span>
                        <button
                          onClick={() => updateQty(item.id, item.qty - 1)}
                          className="grid h-7 w-7 place-items-center rounded-lg text-slate-600 hover:bg-slate-100"
                        >
                          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M5 12h14" />
                          </svg>
                        </button>
                      </div>
                      <span className="text-sm font-extrabold text-brand-700">
                        {faNum(item.price * item.qty)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* footer */}
            <div className="space-y-3 border-t border-slate-100 p-5">
              <div className="flex items-center justify-between text-sm text-slate-500">
                <span>جمع کل</span>
                <span className="font-bold text-slate-800">
                  {faNum(cartTotal)} تومان
                </span>
              </div>
              <div className="flex items-center justify-between text-sm text-slate-500">
                <span>هزینه ارسال</span>
                <span className="font-bold text-emerald-600">
                  {shipping === 0 ? "رایگان" : faNum(shipping) + " تومان"}
                </span>
              </div>
              <div className="flex items-center justify-between border-t border-dashed border-slate-200 pt-3">
                <span className="font-bold text-ink">مبلغ نهایی</span>
                <span className="text-lg font-black text-brand-700">
                  {faNum(cartTotal + shipping)} تومان
                </span>
              </div>
              <Link
                href="/checkout"
                onClick={() => setCartOpen(false)}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand-500/30 transition hover:opacity-90"
              >
                تکمیل خرید
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M19 12H5M12 5l-7 7 7 7" />
                </svg>
              </Link>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
