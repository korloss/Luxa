"use client";

import { useStore } from "@/components/store-provider";

export function Toaster() {
  const { toasts } = useStore();

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-6 z-[60] flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="animate-pop pointer-events-auto flex items-center gap-2.5 rounded-2xl bg-ink/95 px-4 py-3 text-sm font-bold text-white shadow-2xl backdrop-blur"
        >
          <span
            className={`grid h-6 w-6 place-items-center rounded-full text-xs ${
              t.type === "success"
                ? "bg-emerald-500"
                : t.type === "error"
                  ? "bg-rose-500"
                  : "bg-brand-500"
            }`}
          >
            {t.type === "success" ? "✓" : t.type === "error" ? "!" : "♥"}
          </span>
          {t.message}
        </div>
      ))}
    </div>
  );
}
