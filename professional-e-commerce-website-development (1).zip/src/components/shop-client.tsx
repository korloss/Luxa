"use client";

import { useMemo, useState } from "react";
import { ProductCard } from "@/components/product-card";
import { faNum, discountPercent } from "@/lib/format";
import { DEPARTMENTS } from "@/db/schema";
import type { Product, Category } from "@/db/schema";

type Props = {
  products: Product[];
  categories: Category[];
  initialQuery: string;
  initialCat: string;
  initialSort: string;
  initialDept: string;
};

export function ShopClient({
  products,
  categories,
  initialQuery,
  initialCat,
  initialSort,
  initialDept,
}: Props) {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCat);
  const [dept, setDept] = useState(initialDept);
  const [sort, setSort] = useState(initialSort || "newest");
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState(0);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const catMap = useMemo(
    () => new Map(categories.map((c) => [c.id, c.slug])),
    [categories],
  );

  const deptProducts = useMemo(
    () => products.filter((p) => p.department === dept),
    [products, dept],
  );
  const deptCats = useMemo(
    () => categories.filter((c) => c.department === dept),
    [categories, dept],
  );

  const brands = useMemo(
    () =>
      Array.from(
        new Set(deptProducts.map((p) => p.brand).filter((b): b is string => !!b)),
      ),
    [deptProducts],
  );

  const priceBounds = useMemo(() => {
    const prices = deptProducts.map((p) => p.price);
    if (prices.length === 0) return { min: 0, max: 0 };
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    return { min, max };
  }, [deptProducts]);

  // initialize max price once bounds known
  const [priceInited, setPriceInited] = useState(false);
  if (!priceInited && priceBounds.max > 0) {
    setMaxPrice(priceBounds.max);
    setPriceInited(true);
  }

  const filtered = useMemo(() => {
    let result = deptProducts.filter((p) => {
      if (query) {
        const q = query.trim();
        if (
          !p.name.includes(q) &&
          !(p.brand || "").includes(q) &&
          !p.description.includes(q)
        )
          return false;
      }
      if (category && catMap.get(p.categoryId ?? 0) !== category) return false;
      if (selectedBrands.length && !selectedBrands.includes(p.brand || ""))
        return false;
      if (maxPrice && p.price > maxPrice) return false;
      return true;
    });

    result = [...result];
    switch (sort) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        result.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "discount":
        result.sort(
          (a, b) =>
            discountPercent(b.price, b.oldPrice) -
            discountPercent(a.price, a.oldPrice),
        );
        break;
      default:
        break; // newest: keep server order
    }
    return result;
  }, [deptProducts, query, category, selectedBrands, maxPrice, sort, catMap]);

  const resetFilters = () => {
    setQuery("");
    setCategory("");
    setSort("newest");
    setSelectedBrands([]);
    setMaxPrice(priceBounds.max);
  };

  const toggleBrand = (b: string) =>
    setSelectedBrands((prev) =>
      prev.includes(b) ? prev.filter((x) => x !== b) : [...prev, b],
    );

  const activeCount =
    (query ? 1 : 0) +
    (category ? 1 : 0) +
    selectedBrands.length +
    (maxPrice < priceBounds.max ? 1 : 0);

  return (
    <div className="flex gap-6">
      {/* sidebar */}
      <aside
        className={`fixed inset-0 z-50 overflow-y-auto bg-white p-5 lg:static lg:z-0 lg:block lg:w-72 lg:shrink-0 lg:bg-transparent lg:p-0 ${
          filtersOpen ? "block" : "hidden lg:block"
        }`}
      >
        <div className="flex items-center justify-between lg:hidden">
          <h3 className="text-lg font-black">فیلترها</h3>
          <button
            onClick={() => setFiltersOpen(false)}
            className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="mt-4 space-y-5 rounded-3xl border border-slate-100 bg-white p-5 lg:mt-0">
          {/* search */}
          <div>
            <label className="mb-2 block text-sm font-bold text-slate-700">جستجو</label>
            <div className="relative">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="نام محصول..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2.5 pr-9 pl-3 text-sm outline-none focus:border-brand-400 focus:bg-white"
              />
              <svg viewBox="0 0 24 24" className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
            </div>
          </div>

          {/* categories */}
          <div>
            <h4 className="mb-2.5 text-sm font-bold text-slate-700">دسته‌بندی</h4>
            <div className="space-y-1">
              <button
                onClick={() => setCategory("")}
                className={`block w-full rounded-lg px-3 py-2 text-right text-sm transition ${
                  !category ? "bg-brand-50 font-bold text-brand-700" : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                همه دسته‌ها
              </button>
              {deptCats.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCategory(c.slug)}
                  className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-right text-sm transition ${
                    category === c.slug ? "bg-brand-50 font-bold text-brand-700" : "text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <span>{c.icon}</span>
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          {/* brands */}
          <div>
            <h4 className="mb-2.5 text-sm font-bold text-slate-700">برند</h4>
            <div className="space-y-1.5">
              {brands.map((b) => (
                <label
                  key={b}
                  className="flex cursor-pointer items-center gap-2.5 text-sm text-slate-600"
                >
                  <span
                    className={`grid h-5 w-5 place-items-center rounded-md border transition ${
                      selectedBrands.includes(b)
                        ? "border-brand-600 bg-brand-600 text-white"
                        : "border-slate-300"
                    }`}
                  >
                    {selectedBrands.includes(b) && (
                      <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="3"><path d="M20 6 9 17l-5-5" /></svg>
                    )}
                  </span>
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(b)}
                    onChange={() => toggleBrand(b)}
                    className="sr-only"
                  />
                  {b}
                </label>
              ))}
            </div>
          </div>

          {/* price */}
          <div>
            <h4 className="mb-2.5 text-sm font-bold text-slate-700">
              بیشترین قیمت
            </h4>
            <input
              type="range"
              min={priceBounds.min}
              max={priceBounds.max}
              value={maxPrice}
              step={1000000}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-brand-600"
            />
            <div className="mt-1.5 flex justify-between text-xs text-slate-500">
              <span>{faNum(priceBounds.min)}</span>
              <span className="font-bold text-brand-700">تا {faNum(maxPrice)}</span>
            </div>
          </div>

          {activeCount > 0 && (
            <button
              onClick={resetFilters}
              className="w-full rounded-xl border border-slate-200 py-2.5 text-sm font-bold text-slate-600 transition hover:bg-slate-50"
            >
              حذف فیلترها ({faNum(activeCount)})
            </button>
          )}
        </div>
      </aside>

      {filtersOpen && (
        <div
          className="fixed inset-0 z-40 bg-ink/40 lg:hidden"
          onClick={() => setFiltersOpen(false)}
        />
      )}

      {/* content */}
      <div className="min-w-0 flex-1">
        {/* dept switch */}
        <div className="mb-4 flex items-center gap-2">
          {DEPARTMENTS.map((d) => (
            <button
              key={d.id}
              onClick={() => {
                setDept(d.id);
                setCategory("");
                setSelectedBrands([]);
              }}
              className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-bold transition ${
                dept === d.id
                  ? "bg-brand-600 text-white shadow-lg shadow-brand-500/30"
                  : "border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
              }`}
            >
              {d.icon} {d.name}
            </button>
          ))}
        </div>
        {/* toolbar */}
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-white p-3">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setFiltersOpen(true)}
              className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-sm font-bold text-slate-700 lg:hidden"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M6 12h12M10 18h4" /></svg>
              فیلتر
              {activeCount > 0 && (
                <span className="grid h-5 w-5 place-items-center rounded-full bg-brand-600 text-[10px] text-white">{faNum(activeCount)}</span>
              )}
            </button>
            <span className="text-sm text-slate-500">
              <b className="text-slate-900">{faNum(filtered.length)}</b> محصول یافت شد
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="hidden text-sm text-slate-500 sm:inline">مرتب‌سازی:</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 outline-none focus:border-brand-400"
            >
              <option value="newest">جدیدترین</option>
              <option value="price-asc">ارزان‌ترین</option>
              <option value="price-desc">گران‌ترین</option>
              <option value="rating">محبوب‌ترین</option>
              <option value="discount">بیشترین تخفیف</option>
            </select>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-4 rounded-3xl border border-dashed border-slate-200 py-20 text-center">
            <span className="text-6xl">🔍</span>
            <div>
              <p className="text-lg font-bold text-slate-800">محصولی یافت نشد</p>
              <p className="mt-1 text-sm text-slate-500">فیلترها را تغییر دهید</p>
            </div>
            <button
              onClick={resetFilters}
              className="rounded-2xl bg-ink px-5 py-2.5 text-sm font-bold text-white"
            >
              حذف فیلترها
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
