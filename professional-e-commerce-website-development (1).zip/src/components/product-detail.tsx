"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useStore } from "@/components/store-provider";
import { ProductCard } from "@/components/product-card";
import { StarRating } from "@/components/star-rating";
import { faNum, discountPercent, formatDate } from "@/lib/format";
import type { Product, Review } from "@/db/schema";

type Props = {
  product: Product;
  related: Product[];
  initialReviews: Review[];
};

export function ProductDetail({ product, related, initialReviews }: Props) {
  const router = useRouter();
  const { addToCart, toggleWishlist, inWishlist, pushToast } = useStore();
  const gallery = product.gallery?.length ? product.gallery : [product.image];
  const [activeImg, setActiveImg] = useState(gallery[0]);
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState<"desc" | "specs" | "reviews">("desc");
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const off = discountPercent(product.price, product.oldPrice);
  const liked = inWishlist(product.id);

  const handleAdd = (buyNow = false) => {
    addToCart(
      {
        id: product.id,
        slug: product.slug,
        name: product.name,
        price: product.price,
        image: product.image,
      },
      qty,
    );
    if (buyNow) router.push("/checkout");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      {/* breadcrumb */}
      <nav className="mb-6 flex items-center gap-1.5 text-xs text-slate-400">
        <Link href="/" className="hover:text-brand-600">خانه</Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-brand-600">فروشگاه</Link>
        <span>/</span>
        <span className="text-slate-600">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* gallery */}
        <div className="flex flex-col gap-3">
          <div className="relative aspect-square overflow-hidden rounded-3xl border border-slate-100 bg-gradient-to-br from-slate-50 to-slate-100">
            <img
              src={activeImg}
              alt={product.name}
              className="h-full w-full object-cover"
            />
            {off > 0 && (
              <span className="absolute right-4 top-4 rounded-full bg-rose-500 px-3 py-1.5 text-sm font-bold text-white shadow-lg">
                {faNum(off)}٪ تخفیف
              </span>
            )}
          </div>
          {gallery.length > 1 && (
            <div className="flex gap-3">
              {gallery.map((g, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(g)}
                  className={`h-20 w-20 overflow-hidden rounded-2xl border-2 transition ${
                    activeImg === g ? "border-brand-600" : "border-transparent opacity-70 hover:opacity-100"
                  }`}
                >
                  <img src={g} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* info */}
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-brand-600">{product.brand}</span>
            {product.badge && (
              <span className="rounded-full bg-brand-50 px-2.5 py-0.5 text-xs font-bold text-brand-700">
                {product.badge}
              </span>
            )}
          </div>
          <h1 className="mt-2 text-2xl font-black leading-9 text-ink sm:text-3xl">
            {product.name}
          </h1>

          <div className="mt-3 flex items-center gap-3">
            <StarRating rating={product.rating} size="md" showValue />
            <span className="text-sm text-slate-400">
              ({faNum(product.reviewCount)} نظر)
            </span>
            <span
              className={`mr-auto flex items-center gap-1.5 text-sm font-bold ${
                product.stock > 0 ? "text-emerald-600" : "text-rose-500"
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${product.stock > 0 ? "bg-emerald-500" : "bg-rose-500"}`} />
              {product.stock > 0 ? "موجود در انبار" : "ناموجود"}
            </span>
          </div>

          {/* price */}
          <div className="mt-5 flex items-end gap-3 rounded-2xl bg-slate-50 p-5">
            <span className="text-3xl font-black text-ink">
              {faNum(product.price)}
            </span>
            <span className="mb-1 text-sm font-medium text-slate-500">تومان</span>
            {product.oldPrice && product.oldPrice > product.price && (
              <span className="mb-1.5 text-base text-slate-400 line-through">
                {faNum(product.oldPrice)}
              </span>
            )}
          </div>

          <p className="mt-5 text-sm leading-8 text-slate-600">
            {product.description}
          </p>

          {/* quick specs */}
          {product.specs && product.specs.length > 0 && (
            <div className="mt-5 grid grid-cols-2 gap-2">
              {product.specs.slice(0, 4).map((s, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-slate-100 bg-white px-3 py-2.5"
                >
                  <p className="text-[11px] text-slate-400">{s.label}</p>
                  <p className="text-sm font-bold text-slate-800">{s.value}</p>
                </div>
              ))}
            </div>
          )}

          {/* actions */}
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 rounded-2xl border border-slate-200 p-1">
              <button
                onClick={() => setQty((q) => q + 1)}
                className="grid h-9 w-9 place-items-center rounded-xl text-slate-600 hover:bg-slate-100"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14" /></svg>
              </button>
              <span className="w-8 text-center font-bold">{faNum(qty)}</span>
              <button
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="grid h-9 w-9 place-items-center rounded-xl text-slate-600 hover:bg-slate-100"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14" /></svg>
              </button>
            </div>

            <button
              onClick={() => handleAdd(false)}
              disabled={product.stock === 0}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand-500/30 transition hover:opacity-90 disabled:opacity-50"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" /><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6" /></svg>
              افزودن به سبد
            </button>

            <button
              onClick={() => toggleWishlist(product.id)}
              className={`grid h-[52px] w-[52px] shrink-0 place-items-center rounded-2xl border transition ${
                liked ? "border-rose-200 bg-rose-50 text-rose-500" : "border-slate-200 text-slate-500 hover:text-rose-500"
              }`}
              aria-label="علاقه‌مندی"
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill={liked ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2">
                <path d="M12 21s-7.5-4.6-10-9.3C.6 8.4 2.2 5 5.5 5c2 0 3.3 1.1 4.5 2.7C11.2 6.1 12.5 5 14.5 5 17.8 5 19.4 8.4 18 11.7 15.5 16.4 12 21 12 21z" />
              </svg>
            </button>
          </div>

          <button
            onClick={() => handleAdd(true)}
            disabled={product.stock === 0}
            className="mt-3 w-full rounded-2xl border-2 border-ink py-3.5 text-sm font-bold text-ink transition hover:bg-ink hover:text-white disabled:opacity-50"
          >
            خرید آنی
          </button>

          {/* trust */}
          <div className="mt-6 grid grid-cols-3 gap-3 border-t border-slate-100 pt-5 text-center">
            {[
              { i: "🚚", t: "ارسال سریع" },
              { i: "🛡️", t: "ضمانت اصالت" },
              { i: "↩️", t: "بازگشت ۷ روزه" },
            ].map((x) => (
              <div key={x.t} className="flex flex-col items-center gap-1">
                <span className="text-2xl">{x.i}</span>
                <span className="text-xs text-slate-500">{x.t}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* tabs */}
      <div className="mt-12">
        <div className="flex gap-1 border-b border-slate-200">
          {[
            { id: "desc", label: "توضیحات" },
            { id: "specs", label: "مشخصات فنی" },
            { id: "reviews", label: `نظرات (${faNum(reviews.length)})` },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as typeof tab)}
              className={`relative px-5 py-3 text-sm font-bold transition ${
                tab === t.id ? "text-brand-600" : "text-slate-500 hover:text-slate-800"
              }`}
            >
              {t.label}
              {tab === t.id && (
                <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-brand-600" />
              )}
            </button>
          ))}
        </div>

        <div className="py-6">
          {tab === "desc" && (
            <p className="max-w-3xl text-sm leading-8 text-slate-600">
              {product.description}
            </p>
          )}
          {tab === "specs" && (
            <div className="max-w-2xl overflow-hidden rounded-2xl border border-slate-100">
              {product.specs?.map((s, i) => (
                <div
                  key={i}
                  className={`flex justify-between px-5 py-3.5 text-sm ${i % 2 ? "bg-white" : "bg-slate-50"}`}
                >
                  <span className="text-slate-500">{s.label}</span>
                  <span className="font-bold text-slate-800">{s.value}</span>
                </div>
              ))}
            </div>
          )}
          {tab === "reviews" && (
            <ReviewSection
              productId={product.id}
              reviews={reviews}
              onAdd={(r) => setReviews((prev) => [r, ...prev])}
              notify={pushToast}
            />
          )}
        </div>
      </div>

      {/* related */}
      {related.length > 0 && (
        <div className="mt-12">
          <h2 className="mb-6 text-xl font-black text-ink">محصولات مرتبط</h2>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ReviewSection({
  productId,
  reviews,
  onAdd,
  notify,
}: {
  productId: number;
  reviews: Review[];
  onAdd: (r: Review) => void;
  notify: (m: string, t?: "success" | "info" | "error") => void;
}) {
  const [name, setName] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [hover, setHover] = useState(0);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, name, rating, comment }),
      });
      if (!res.ok) throw new Error();
      const created = await res.json();
      onAdd(created);
      setName("");
      setComment("");
      setRating(5);
      notify("نظر شما ثبت شد", "success");
    } catch {
      notify("خطا در ثبت نظر", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      {/* list */}
      <div className="space-y-4">
        {reviews.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 p-8 text-center text-sm text-slate-500">
            هنوز نظری ثبت نشده است. اولین نفر باشید!
          </div>
        ) : (
          reviews.map((r) => (
            <div key={r.id} className="rounded-2xl border border-slate-100 bg-white p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-fuchsia-500 font-bold text-white">
                    {r.name.charAt(0)}
                  </span>
                  <div>
                    <p className="text-sm font-bold text-slate-800">{r.name}</p>
                    <p className="text-xs text-slate-400">{formatDate(r.createdAt)}</p>
                  </div>
                </div>
                <StarRating rating={r.rating} />
              </div>
              <p className="mt-3 text-sm leading-7 text-slate-600">{r.comment}</p>
            </div>
          ))
        )}
      </div>

      {/* form */}
      <form
        onSubmit={submit}
        className="h-fit rounded-3xl border border-slate-100 bg-slate-50/50 p-6"
      >
        <h3 className="text-lg font-black text-ink">ثبت نظر شما</h3>
        <p className="mt-1 text-xs text-slate-500">نظرتان درباره محصول را بنویسید</p>

        <div className="mt-4">
          <label className="mb-2 block text-sm font-bold text-slate-700">امتیاز</label>
          <div className="flex gap-1" onMouseLeave={() => setHover(0)}>
            {[1, 2, 3, 4, 5].map((s) => (
              <button
                key={s}
                type="button"
                onMouseEnter={() => setHover(s)}
                onClick={() => setRating(s)}
                className="text-2xl transition"
              >
                <span className={s <= (hover || rating) ? "text-amber-400" : "text-slate-200"}>★</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4">
          <label className="mb-2 block text-sm font-bold text-slate-700">نام</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm outline-none focus:border-brand-400"
          />
        </div>

        <div className="mt-4">
          <label className="mb-2 block text-sm font-bold text-slate-700">متن نظر</label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            required
            rows={4}
            className="w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm outline-none focus:border-brand-400"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="mt-4 w-full rounded-2xl bg-ink py-3 text-sm font-bold text-white transition hover:bg-brand-700 disabled:opacity-50"
        >
          {loading ? "در حال ثبت..." : "ثبت نظر"}
        </button>
      </form>
    </div>
  );
}
