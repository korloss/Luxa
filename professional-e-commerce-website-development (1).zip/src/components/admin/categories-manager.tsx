"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store-provider";
import { DEPARTMENTS } from "@/db/schema";
import type { Category } from "@/db/schema";
import { faNum } from "@/lib/format";

const COLORS = [
  "from-brand-500 to-fuchsia-500",
  "from-indigo-500 to-violet-600",
  "from-sky-500 to-blue-600",
  "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-600",
  "from-rose-500 to-red-600",
  "from-slate-600 to-slate-800",
];

export function CategoriesManager({ initial }: { initial: Category[] }) {
  const router = useRouter();
  const { pushToast } = useStore();
  const [list, setList] = useState<Category[]>(initial);
  const [editing, setEditing] = useState<Category | null>(null);
  const [showForm, setShowForm] = useState(false);

  const refresh = () => router.refresh();

  const blank = {
    name: "",
    slug: "",
    icon: "🛍️",
    color: COLORS[0],
    description: "",
    department: "tech",
  };
  const [form, setForm] = useState<Record<string, string>>(blank);

  const openNew = () => {
    setForm(blank);
    setEditing(null);
    setShowForm(true);
  };
  const openEdit = (c: Category) => {
    setForm({
      name: c.name,
      slug: c.slug,
      icon: c.icon ?? "",
      color: c.color ?? COLORS[0],
      description: c.description ?? "",
      department: c.department,
    });
    setEditing(c);
    setShowForm(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const method = editing ? "PUT" : "POST";
    const url = editing ? `/api/admin/categories/${editing.id}` : "/api/admin/categories";
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      pushToast(editing ? "دسته‌بندی به‌روزرسانی شد" : "دسته‌بندی ایجاد شد", "success");
      setShowForm(false);
      const updated = await fetch("/api/admin/categories").then((r) => r.json());
      if (Array.isArray(updated)) setList(updated);
      refresh();
    } else {
      pushToast("خطا در ذخیره", "error");
    }
  };

  const del = async (c: Category) => {
    if (!confirm(`حذف دسته‌بندی «${c.name}»؟`)) return;
    const res = await fetch(`/api/admin/categories/${c.id}`, { method: "DELETE" });
    if (res.ok) {
      pushToast("دسته‌بندی حذف شد", "success");
      setList((prev) => prev.filter((x) => x.id !== c.id));
      refresh();
    }
  };

  const inputCls = "w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-brand-400 focus:ring-2 focus:ring-brand-100";

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-ink">دسته‌بندی‌ها</h1>
          <p className="mt-1 text-sm text-slate-500">{faNum(list.length)} دسته‌بندی</p>
        </div>
        <button onClick={openNew} className="rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-brand-500/30">
          + دسته جدید
        </button>
      </div>

      {DEPARTMENTS.map((d) => {
        const cats = list.filter((c) => c.department === d.id);
        return (
          <div key={d.id} className="rounded-3xl border border-slate-100 bg-white p-5">
            <h2 className="mb-4 flex items-center gap-2 font-black text-ink">{d.icon} {d.name}</h2>
            {cats.length === 0 ? (
              <p className="py-6 text-center text-sm text-slate-400">دسته‌بندی‌ای وجود ندارد</p>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {cats.map((c) => (
                  <div key={c.id} className="flex items-center gap-3 rounded-2xl border border-slate-100 p-3">
                    <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-br ${c.color} text-2xl`}>{c.icon}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-slate-800">{c.name}</p>
                      <p className="truncate text-xs text-slate-400" dir="ltr">{c.slug}</p>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(c)} className="grid h-8 w-8 place-items-center rounded-lg bg-brand-50 text-brand-600 hover:bg-brand-100" title="ویرایش">
                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                      </button>
                      <button onClick={() => del(c)} className="grid h-8 w-8 place-items-center rounded-lg bg-rose-50 text-rose-500 hover:bg-rose-100" title="حذف">
                        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}

      {/* modal form */}
      {showForm && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-ink/60 backdrop-blur-sm" onClick={() => setShowForm(false)} />
          <form onSubmit={save} className="relative w-full max-w-lg space-y-4 rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-ink">{editing ? "ویرایش دسته‌بندی" : "دسته‌بندی جدید"}</h3>
              <button type="button" onClick={() => setShowForm(false)} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="mb-2 block text-sm font-bold text-slate-700">نام *</span>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-2 block text-sm font-bold text-slate-700">آیکون (اموجی)</span>
                <input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} className={inputCls} placeholder="📱" />
              </label>
              <label className="block">
                <span className="mb-2 block text-sm font-bold text-slate-700">اسلاگ</span>
                <input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} dir="ltr" className={inputCls} placeholder="خالی=خودکار" />
              </label>
              <label className="block">
                <span className="mb-2 block text-sm font-bold text-slate-700">دپارتمان</span>
                <select value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className={inputCls}>
                  <option value="tech">💻 دیجیتال</option>
                  <option value="food">🛒 مواد غذایی</option>
                </select>
              </label>
            </div>
            <label className="block">
              <span className="mb-2 block text-sm font-bold text-slate-700">توضیحات</span>
              <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={inputCls} />
            </label>
            <div>
              <span className="mb-2 block text-sm font-bold text-slate-700">رنگ</span>
              <div className="flex flex-wrap gap-2">
                {COLORS.map((c) => (
                  <button key={c} type="button" onClick={() => setForm({ ...form, color: c })} className={`h-9 w-9 rounded-lg bg-gradient-to-br ${c} ${form.color === c ? "ring-2 ring-slate-800 ring-offset-2" : ""}`} />
                ))}
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="flex-1 rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 py-3 text-sm font-bold text-white">ذخیره</button>
              <button type="button" onClick={() => setShowForm(false)} className="rounded-2xl border border-slate-200 px-6 py-3 text-sm font-bold text-slate-600">انصراف</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
