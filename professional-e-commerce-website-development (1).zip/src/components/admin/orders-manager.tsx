"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/components/store-provider";
import type { Order } from "@/db/schema";
import { faNum, formatDate } from "@/lib/format";

const STATUSES = ["در حال پردازش", "ارسال شده", "تحویل داده شده", "لغو شده"];

const statusStyle: Record<string, string> = {
  "در حال پردازش": "bg-amber-100 text-amber-700",
  "ارسال شده": "bg-sky-100 text-sky-700",
  "تحویل داده شده": "bg-emerald-100 text-emerald-700",
  "لغو شده": "bg-rose-100 text-rose-700",
};

export function OrdersManager() {
  const { pushToast } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<Order | null>(null);

  const load = async () => {
    setLoading(true);
    const res = await fetch("/api/admin/orders");
    const data = await res.json();
    setOrders(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const changeStatus = async (id: number, status: string) => {
    const res = await fetch(`/api/admin/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      pushToast("وضعیت به‌روزرسانی شد", "success");
      setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
      setSelected((prev) => (prev && prev.id === id ? { ...prev, status } : prev));
    } else {
      pushToast("خطا", "error");
    }
  };

  const del = async (o: Order) => {
    if (!confirm(`حذف سفارش ${o.code}؟`)) return;
    const res = await fetch(`/api/admin/orders/${o.id}`, { method: "DELETE" });
    if (res.ok) {
      pushToast("سفارش حذف شد", "success");
      setOrders((prev) => prev.filter((x) => x.id !== o.id));
    }
  };

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);
  const totalRevenue = orders
    .filter((o) => o.status === "تحویل داده شده")
    .reduce((s, o) => s + o.total, 0);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-ink">سفارش‌ها</h1>
          <p className="mt-1 text-sm text-slate-500">
            {faNum(orders.length)} سفارش • درآمد تحویلی: {faNum(totalRevenue)} ت
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {["all", ...STATUSES].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                filter === s ? "bg-brand-600 text-white" : "bg-white text-slate-600 hover:bg-slate-100"
              }`}
            >
              {s === "all" ? "همه" : s}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <p className="py-16 text-center text-sm text-slate-400">در حال بارگذاری...</p>
      ) : filtered.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-200 py-16 text-center">
          <p className="text-4xl">🧾</p>
          <p className="mt-2 text-sm text-slate-400">سفارشی یافت نشد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((o) => (
            <div key={o.id} className="rounded-3xl border border-slate-100 bg-white p-4">
              <div className="flex flex-wrap items-center gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-ink" dir="ltr">{o.code}</span>
                    <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${statusStyle[o.status] ?? "bg-slate-100"}`}>{o.status}</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-600">{o.fullName} • {o.phone}</p>
                  <p className="text-xs text-slate-400">{formatDate(o.createdAt)} • {faNum(o.items?.length ?? 0)} کالا</p>
                </div>
                <div className="text-left">
                  <p className="text-lg font-black text-brand-700">{faNum(o.total)}</p>
                  <p className="text-[11px] text-slate-400">تومان</p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={o.status}
                    onChange={(e) => changeStatus(o.id, e.target.value)}
                    className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 outline-none focus:border-brand-400"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                  <button onClick={() => setSelected(o)} className="grid h-9 w-9 place-items-center rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200" title="جزئیات">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
                  </button>
                  <button onClick={() => del(o)} className="grid h-9 w-9 place-items-center rounded-xl bg-rose-50 text-rose-500 hover:bg-rose-100" title="حذف">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* detail modal */}
      {selected && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-ink/60 backdrop-blur-sm" onClick={() => setSelected(null)} />
          <div className="relative max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="font-black text-ink" dir="ltr">{selected.code}</h3>
                <p className="text-xs text-slate-400">{formatDate(selected.createdAt)}</p>
              </div>
              <button onClick={() => setSelected(null)} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
              </button>
            </div>

            <div className="mb-4 space-y-2 rounded-2xl bg-slate-50 p-4 text-sm">
              <div className="flex justify-between"><span className="text-slate-400">نام:</span><span className="font-bold">{selected.fullName}</span></div>
              <div className="flex justify-between"><span className="text-slate-400">تلفن:</span><span dir="ltr">{selected.phone}</span></div>
              {selected.city && <div className="flex justify-between"><span className="text-slate-400">شهر:</span><span>{selected.city}</span></div>}
              <div className="flex justify-between gap-4"><span className="shrink-0 text-slate-400">آدرس:</span><span className="text-left">{selected.address}</span></div>
              {selected.notes && <div className="flex justify-between gap-4"><span className="shrink-0 text-slate-400">یادداشت:</span><span className="text-left">{selected.notes}</span></div>}
            </div>

            <h4 className="mb-2 text-sm font-black text-ink">اقلام</h4>
            <div className="space-y-2">
              {selected.items?.map((item) => (
                <div key={item.id} className="flex items-center gap-3 rounded-2xl border border-slate-100 p-2">
                  <img src={item.image} alt="" className="h-12 w-12 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-slate-800">{item.name}</p>
                    <p className="text-xs text-slate-400">{faNum(item.qty)} × {faNum(item.price)}</p>
                  </div>
                  <span className="text-sm font-bold text-slate-700">{faNum(item.price * item.qty)}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 flex justify-between border-t border-slate-100 pt-4">
              <span className="font-black text-ink">مجموع</span>
              <span className="text-lg font-black text-brand-700">{faNum(selected.total)} ت</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
