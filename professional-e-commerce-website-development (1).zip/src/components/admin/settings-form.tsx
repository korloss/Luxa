"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useStore } from "@/components/store-provider";
import type { Setting } from "@/db/schema";

const PRESET_COLORS: { name: string; primary: string; accent: string }[] = [
  { name: "بنفش", primary: "#7c3aed", accent: "#ec4899" },
  { name: "آبی", primary: "#2563eb", accent: "#06b6d4" },
  { name: "سبز", primary: "#059669", accent: "#84cc16" },
  { name: "نارنجی", primary: "#ea580c", accent: "#f59e0b" },
  { name: "قرمز", primary: "#dc2626", accent: "#f43f5e" },
  { name: "فیروزه‌ای", primary: "#0891b2", accent: "#6366f1" },
];

export function SettingsForm({ initial }: { initial?: Setting }) {
  const router = useRouter();
  const { pushToast } = useStore();
  const [form, setForm] = useState({
    heroBadge: initial?.heroBadge ?? "",
    heroTitle: initial?.heroTitle ?? "",
    heroHighlight: initial?.heroHighlight ?? "",
    heroSubtitle: initial?.heroSubtitle ?? "",
    announcementText: initial?.announcementText ?? "",
    primaryColor: initial?.primaryColor ?? "#7c3aed",
    accentColor: initial?.accentColor ?? "#ec4899",
    contactPhone: initial?.contactPhone ?? "",
    contactEmail: initial?.contactEmail ?? "",
    contactAddress: initial?.contactAddress ?? "",
    freeShipThreshold: initial?.freeShipThreshold ?? 5000000,
    shippingFee: initial?.shippingFee ?? 250000,
    showFood: initial?.showFood ?? true,
  });
  const [saving, setSaving] = useState(false);

  const set = (k: keyof typeof form, v: string | number | boolean) =>
    setForm((p) => ({ ...p, [k]: v }));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "خطا");
      }
      pushToast("تنظیمات ذخیره شد", "success");
      router.refresh();
    } catch (err) {
      pushToast(err instanceof Error ? err.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const inputCls =
    "w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-brand-400 focus:ring-2 focus:ring-brand-100";

  return (
    <form onSubmit={save} className="space-y-5">
      {/* Chideman / Layout */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-1 flex items-center gap-2 font-black text-ink">🎨 چیدمان و بخش‌ها</h2>
        <p className="mb-4 text-xs text-slate-500">نمایش یا مخفی کردن بخش‌های سایت</p>
        <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-100 bg-slate-50/50 p-4">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🛒</span>
            <div>
              <p className="text-sm font-bold text-slate-800">بخش مواد غذایی (سوپرمارکت)</p>
              <p className="text-xs text-slate-400">نمایش دسته‌بندی و محصولات غذایی در سایت</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => set("showFood", !form.showFood)}
            className={`relative h-7 w-12 rounded-full transition ${form.showFood ? "bg-emerald-500" : "bg-slate-300"}`}
          >
            <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${form.showFood ? "right-1" : "right-6"}`} />
          </button>
        </label>
      </div>

      {/* Hero */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 flex items-center gap-2 font-black text-ink">✨ محتوای بنر اصلی (هیرو)</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="متن بالای بنر (Badge)">
            <input value={form.heroBadge} onChange={(e) => set("heroBadge", e.target.value)} className={inputCls} />
          </Field>
          <Field label="عنوان برجسته (رنگی)">
            <input value={form.heroHighlight} onChange={(e) => set("heroHighlight", e.target.value)} className={inputCls} />
          </Field>
          <Field label="عنوان اصلی" full>
            <input value={form.heroTitle} onChange={(e) => set("heroTitle", e.target.value)} className={inputCls} />
          </Field>
          <Field label="توضیحات بنر" full>
            <textarea value={form.heroSubtitle} onChange={(e) => set("heroSubtitle", e.target.value)} rows={2} className={`${inputCls} resize-none`} />
          </Field>
        </div>
      </div>

      {/* Announcement */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 flex items-center gap-2 font-black text-ink">📢 نوار اعلان بالای سایت</h2>
        <Field label="متن اعلان">
          <input value={form.announcementText} onChange={(e) => set("announcementText", e.target.value)} className={inputCls} />
        </Field>
      </div>

      {/* Colors */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-1 flex items-center gap-2 font-black text-ink">🎨 رنگ‌بندی سایت</h2>
        <p className="mb-4 text-xs text-slate-500">رنگ اصلی و رنگ تأکیدی کل سایت را تغییر دهید</p>
        <div className="mb-4 grid grid-cols-3 gap-2 sm:grid-cols-6">
          {PRESET_COLORS.map((c) => {
            const active = form.primaryColor === c.primary && form.accentColor === c.accent;
            return (
              <button
                key={c.name}
                type="button"
                onClick={() => {
                  set("primaryColor", c.primary);
                  set("accentColor", c.accent);
                }}
                className={`flex flex-col items-center gap-1.5 rounded-2xl border-2 p-2.5 transition ${active ? "border-brand-500 bg-brand-50" : "border-slate-200 hover:border-slate-300"}`}
              >
                <span className="h-8 w-full rounded-lg" style={{ background: `linear-gradient(135deg, ${c.primary}, ${c.accent})` }} />
                <span className="text-[11px] font-bold text-slate-600">{c.name}</span>
              </button>
            );
          })}
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="رنگ اصلی">
            <div className="flex items-center gap-2">
              <input type="color" value={form.primaryColor} onChange={(e) => set("primaryColor", e.target.value)} className="h-11 w-14 shrink-0 cursor-pointer rounded-lg border border-slate-200" />
              <input value={form.primaryColor} onChange={(e) => set("primaryColor", e.target.value)} dir="ltr" className={inputCls} />
            </div>
          </Field>
          <Field label="رنگ تأکیدی">
            <div className="flex items-center gap-2">
              <input type="color" value={form.accentColor} onChange={(e) => set("accentColor", e.target.value)} className="h-11 w-14 shrink-0 cursor-pointer rounded-lg border border-slate-200" />
              <input value={form.accentColor} onChange={(e) => set("accentColor", e.target.value)} dir="ltr" className={inputCls} />
            </div>
          </Field>
        </div>
      </div>

      {/* Shipping */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 flex items-center gap-2 font-black text-ink">🚚 تنظیمات ارسال</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="آستانه ارسال رایگان (تومان)">
            <input type="number" value={form.freeShipThreshold} onChange={(e) => set("freeShipThreshold", Number(e.target.value))} className={inputCls} />
          </Field>
          <Field label="هزینه ارسال (تومان)">
            <input type="number" value={form.shippingFee} onChange={(e) => set("shippingFee", Number(e.target.value))} className={inputCls} />
          </Field>
        </div>
      </div>

      {/* Contact */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 flex items-center gap-2 font-black text-ink">📞 اطلاعات تماس</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="تلفن">
            <input value={form.contactPhone} onChange={(e) => set("contactPhone", e.target.value)} className={inputCls} />
          </Field>
          <Field label="ایمیل">
            <input value={form.contactEmail} onChange={(e) => set("contactEmail", e.target.value)} dir="ltr" className={inputCls} />
          </Field>
          <Field label="آدرس" full>
            <input value={form.contactAddress} onChange={(e) => set("contactAddress", e.target.value)} className={inputCls} />
          </Field>
        </div>
      </div>

      {/* actions */}
      <div className="sticky bottom-4 z-10 flex justify-end">
        <button type="submit" disabled={saving} className="rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 px-8 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-500/30 transition hover:opacity-90 disabled:opacity-50">
          {saving ? "در حال ذخیره..." : "💾 ذخیره تنظیمات"}
        </button>
      </div>
    </form>
  );
}

function Field({ label, full, children }: { label: string; full?: boolean; children: React.ReactNode }) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`}>
      <span className="mb-2 block text-sm font-bold text-slate-700">{label}</span>
      {children}
    </label>
  );
}
