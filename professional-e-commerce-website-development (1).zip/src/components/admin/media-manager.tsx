"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/components/store-provider";

type MediaItem = { id: number; url: string; name: string | null };

async function compressImage(file: File, maxSize = 1000, quality = 0.8): Promise<File> {
  if (file.size < 600 * 1024 && file.type === "image/jpeg") return file;
  return new Promise((resolve) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = (e) => {
      img.src = e.target?.result as string;
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxSize) {
          height = Math.round((height * maxSize) / width);
          width = maxSize;
        } else if (height > maxSize) {
          width = Math.round((width * maxSize) / height);
          height = maxSize;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) return resolve(file);
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (blob) resolve(new File([blob], file.name.replace(/\.\w+$/, ".jpg"), { type: "image/jpeg" }));
            else resolve(file);
          },
          "image/jpeg",
          quality,
        );
      };
      img.onerror = () => resolve(file);
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
}

export function MediaManager() {
  const { pushToast } = useStore();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [copied, setCopied] = useState<number | null>(null);

  const load = async () => {
    setLoading(true);
    const res = await fetch("/api/admin/media");
    const data = await res.json();
    setItems(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const upload = async (rawFile: File) => {
    setUploading(true);
    try {
      const file = await compressImage(rawFile);
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "خطا");
      }
      pushToast("تصویر آپلود شد", "success");
      await load();
    } catch (err) {
      pushToast(err instanceof Error ? err.message : "خطا در آپلود", "error");
    } finally {
      setUploading(false);
    }
  };

  const del = async (m: MediaItem) => {
    if (!confirm("حذف این تصویر؟")) return;
    const res = await fetch(`/api/admin/media/${m.id}`, { method: "DELETE" });
    if (res.ok) {
      pushToast("تصویر حذف شد", "success");
      setItems((prev) => prev.filter((x) => x.id !== m.id));
    }
  };

  const copyUrl = async (m: MediaItem) => {
    try {
      await navigator.clipboard.writeText(m.url);
      setCopied(m.id);
      setTimeout(() => setCopied(null), 1500);
    } catch {
      pushToast("کپی ناموفق", "error");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-ink">رسانه و گالری</h1>
          <p className="mt-1 text-sm text-slate-500">آپلود و مدیریت تصاویر سایت</p>
        </div>
      </div>

      {/* upload zone */}
      <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-3xl border-2 border-dashed border-brand-200 bg-brand-50/40 py-10 transition hover:bg-brand-50">
        <span className="text-4xl">{uploading ? "⏳" : "📤"}</span>
        <span className="text-sm font-bold text-brand-700">
          {uploading ? "در حال آپلود..." : "برای آپلود کلیک کنید یا تصویر را اینجا رها کنید"}
        </span>
        <span className="text-xs text-slate-400">JPG, PNG, WEBP — حداکثر ۸۰۰KB (فشرده‌سازی خودکار)</span>
        <input
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={async (e) => {
            const files = Array.from(e.target.files ?? []);
            for (const f of files) await upload(f);
            e.target.value = "";
          }}
        />
      </label>

      {loading ? (
        <p className="py-16 text-center text-sm text-slate-400">در حال بارگذاری...</p>
      ) : items.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-200 py-16 text-center">
          <p className="text-4xl">🖼️</p>
          <p className="mt-2 text-sm text-slate-400">هنوز تصویری آپلود نشده است</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((m) => (
            <div key={m.id} className="group overflow-hidden rounded-2xl border border-slate-100 bg-white">
              <div className="relative aspect-square bg-slate-50">
                <img src={m.url} alt={m.name || ""} className="h-full w-full object-cover" />
                <button
                  onClick={() => del(m)}
                  className="absolute left-2 top-2 grid h-8 w-8 place-items-center rounded-lg bg-white/90 text-rose-500 opacity-0 shadow transition hover:bg-rose-500 hover:text-white group-hover:opacity-100"
                  title="حذف"
                >
                  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
                </button>
              </div>
              <div className="p-2">
                <button onClick={() => copyUrl(m)} className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-slate-100 py-1.5 text-xs font-bold text-slate-600 transition hover:bg-slate-200">
                  {copied === m.id ? "✓ کپی شد" : "📋 کپی آدرس"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
