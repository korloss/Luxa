"use client";

import { useEffect, useState } from "react";

type MediaItem = { id: number; url: string; name: string | null };

/** فشرده‌سازی تصویر سمت کلاینت برای رعایت محدودیت حجم آپلود */
async function compressImage(file: File, maxSize = 1000, quality = 0.8): Promise<File> {
  // اگر تصویر کوچک و از قبل سبک است، تغییر نده
  if (file.size < 600 * 1024 && file.type === "image/jpeg") return file;

  return new Promise((resolve) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = (e) => {
      img.src = e.target?.result as string;
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxSize) {
          height = Math.round((height * maxSize) / width);
          width = maxSize;
        } else if (height > maxSize) {
          width = Math.round((width * maxSize) / height);
          height = maxSize;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(file);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(new File([blob], file.name.replace(/\.\w+$/, ".jpg"), { type: "image/jpeg" }));
            } else {
              resolve(file);
            }
          },
          "image/jpeg",
          quality,
        );
      };
      img.onerror = () => resolve(file);
    };
    reader.onerror = () => resolve(file);
    reader.readAsDataURL(file);
  });
}

export function MediaPicker({
  open,
  onClose,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (url: string) => void;
}) {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    const res = await fetch("/api/admin/media");
    const data = await res.json();
    setItems(Array.isArray(data) ? data : []);
    setLoading(false);
  };

  useEffect(() => {
    if (open) load();
  }, [open]);

  const upload = async (rawFile: File) => {
    setUploading(true);
    setError("");
    try {
      const file = await compressImage(rawFile);
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "خطا در آپلود");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطا در آپلود");
    } finally {
      setUploading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ink/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative flex max-h-[85vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-100 p-5">
          <h3 className="font-black text-ink">🖼️ انتخاب از گالری رسانه</h3>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200">
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="space-y-2 border-b border-slate-100 p-4">
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-brand-200 bg-brand-50/50 py-4 text-sm font-bold text-brand-700 transition hover:bg-brand-50">
            <span className="text-lg">{uploading ? "⏳" : "⬆️"}</span>
            {uploading ? "در حال آپلود..." : "آپلود تصویر جدید"}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) upload(f);
                e.target.value = "";
              }}
            />
          </label>
          {error && <p className="text-center text-xs font-bold text-rose-600">{error}</p>}
          <p className="text-center text-[11px] text-slate-400">
            تصاویر بزرگ به‌صورت خودکار فشرده می‌شوند (حداکثر ۸۰۰KB)
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <p className="py-10 text-center text-sm text-slate-400">در حال بارگذاری...</p>
          ) : items.length === 0 ? (
            <div className="py-10 text-center">
              <p className="text-4xl">📷</p>
              <p className="mt-2 text-sm text-slate-400">هنوز تصویری آپلود نشده است</p>
              <p className="text-xs text-slate-400">از کادر بالا تصویر جدید آپلود کنید</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
              {items.map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    onSelect(m.url);
                    onClose();
                  }}
                  className="group relative aspect-square overflow-hidden rounded-2xl border border-slate-200 transition hover:border-brand-500 hover:ring-2 hover:ring-brand-200"
                >
                  <img src={m.url} alt={m.name || ""} className="h-full w-full object-cover" />
                  <span className="absolute inset-0 grid place-items-center bg-brand-600/0 text-white opacity-0 transition group-hover:bg-brand-600/40 group-hover:opacity-100">
                    <span className="rounded-lg bg-white/90 px-2 py-1 text-xs font-bold text-brand-700">انتخاب</span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
