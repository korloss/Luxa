"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MediaPicker } from "@/components/admin/media-picker";
import { useStore } from "@/components/store-provider";
import type { Category, Product } from "@/db/schema";

const COLORS = [
  "from-brand-500 to-fuchsia-500",
  "from-indigo-500 to-violet-600",
  "from-sky-500 to-blue-600",
  "from-emerald-500 to-teal-600",
  "from-amber-500 to-orange-600",
  "from-rose-500 to-red-600",
  "from-slate-600 to-slate-800",
];

export function ProductForm({
  product,
  categories,
}: {
  product?: Product;
  categories: Category[];
}) {
  const router = useRouter();
  const { pushToast } = useStore();
  const isEdit = !!product;

  const [form, setForm] = useState({
    name: product?.name ?? "",
    slug: product?.slug ?? "",
    description: product?.description ?? "",
    brand: product?.brand ?? "",
    price: product?.price ?? 0,
    oldPrice: product?.oldPrice ?? 0,
    stock: product?.stock ?? 0,
    badge: product?.badge ?? "",
    department: product?.department ?? "tech",
    categoryId: product?.categoryId ?? 0,
    featured: product?.featured ?? false,
    rating: product?.rating ?? 0,
    reviewCount: product?.reviewCount ?? 0,
    image: product?.image ?? "",
  });
  const [gallery, setGallery] = useState<string[]>(product?.gallery ?? []);
  const [specs, setSpecs] = useState<{ label: string; value: string }[]>(
    product?.specs ?? [],
  );
  const [pickerTarget, setPickerTarget] = useState<"image" | "gallery" | null>(null);
  const [saving, setSaving] = useState(false);

  const set = (k: keyof typeof form, v: string | number | boolean) =>
    setForm((p) => ({ ...p, [k]: v }));

  const filteredCats = categories.filter((c) => c.department === form.department);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      ...form,
      oldPrice: form.oldPrice || null,
      categoryId: form.categoryId || null,
      gallery,
      specs: specs.filter((s) => s.label && s.value),
    };
    try {
      const url = isEdit ? `/api/admin/products/${product!.id}` : "/api/admin/products";
      const method = isEdit ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "خطا");
      }
      pushToast(isEdit ? "محصول به‌روزرسانی شد" : "محصول ایجاد شد", "success");
      router.push("/admin/products");
      router.refresh();
    } catch (err) {
      pushToast(err instanceof Error ? err.message : "خطا", "error");
    } finally {
      setSaving(false);
    }
  };

  const inputCls = "w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none transition focus:border-brand-400 focus:ring-2 focus:ring-brand-100";

  return (
    <form onSubmit={save} className="space-y-5">
      {/* basics */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 font-black text-ink">اطلاعات پایه</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="نام محصول *" full>
            <input required value={form.name} onChange={(e) => set("name", e.target.value)} className={inputCls} />
          </Field>
          <Field label="اسلاگ (آدرس URL)">
            <input value={form.slug} onChange={(e) => set("slug", e.target.value)} dir="ltr" className={inputCls} placeholder="خالی=خودکار" />
          </Field>
          <Field label="برند">
            <input value={form.brand} onChange={(e) => set("brand", e.target.value)} className={inputCls} />
          </Field>
          <Field label="توضیحات" full>
            <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={3} className={`${inputCls} resize-none`} />
          </Field>
        </div>
      </div>

      {/* classification */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 font-black text-ink">دسته‌بندی</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="دپارتمان">
            <select value={form.department} onChange={(e) => set("department", e.target.value)} className={inputCls}>
              <option value="tech">💻 دیجیتال</option>
              <option value="food">🛒 مواد غذایی</option>
            </select>
          </Field>
          <Field label="دسته‌بندی">
            <select value={form.categoryId} onChange={(e) => set("categoryId", Number(e.target.value))} className={inputCls}>
              <option value={0}>— انتخاب —</option>
              {filteredCats.map((c) => (
                <option key={c.id} value={c.id}>{c.icon} {c.name}</option>
              ))}
            </select>
          </Field>
          <Field label="برچسب (Badge)">
            <input value={form.badge} onChange={(e) => set("badge", e.target.value)} className={inputCls} placeholder="مثلاً تخفیف، جدید" />
          </Field>
        </div>
        <label className="mt-4 flex cursor-pointer items-center gap-2.5">
          <input type="checkbox" checked={form.featured} onChange={(e) => set("featured", e.target.checked)} className="h-5 w-5 accent-brand-600" />
          <span className="text-sm font-bold text-slate-700">⭐ محصول منتخب (نمایش در صفحه اصلی)</span>
        </label>
      </div>

      {/* pricing & stock */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 font-black text-ink">قیمت و موجودی</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="قیمت (تومان) *">
            <input required type="number" value={form.price} onChange={(e) => set("price", Number(e.target.value))} className={inputCls} />
          </Field>
          <Field label="قیمت قبلی (تخفیف)">
            <input type="number" value={form.oldPrice} onChange={(e) => set("oldPrice", Number(e.target.value))} className={inputCls} />
          </Field>
          <Field label="موجودی">
            <input type="number" value={form.stock} onChange={(e) => set("stock", Number(e.target.value))} className={inputCls} />
          </Field>
          <Field label="امتیاز (۰-۵)">
            <input type="number" step="0.1" value={form.rating} onChange={(e) => set("rating", Number(e.target.value))} className={inputCls} />
          </Field>
        </div>
      </div>

      {/* images */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <h2 className="mb-4 font-black text-ink">تصاویر</h2>
        <Field label="تصویر اصلی">
          <div className="flex gap-2">
            <input value={form.image} onChange={(e) => set("image", e.target.value)} dir="ltr" className={inputCls} placeholder="آدرس تصویر" />
            <button type="button" onClick={() => setPickerTarget("image")} className="shrink-0 rounded-xl bg-brand-50 px-4 text-sm font-bold text-brand-700 hover:bg-brand-100">🖼️ گالری</button>
          </div>
          {form.image && <img src={form.image} alt="" className="mt-2 h-24 w-24 rounded-xl object-cover" />}
        </Field>

        <div className="mt-4">
          <div className="mb-2 flex items-center justify-between">
            <label className="text-sm font-bold text-slate-700">گالری تصاویر</label>
            <button type="button" onClick={() => setPickerTarget("gallery")} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-200">+ افزودن</button>
          </div>
          <div className="flex flex-wrap gap-2">
            {gallery.map((g, i) => (
              <div key={i} className="group relative">
                <img src={g} alt="" className="h-20 w-20 rounded-xl object-cover" />
                <button type="button" onClick={() => setGallery(gallery.filter((_, idx) => idx !== i))} className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-rose-500 text-xs text-white opacity-0 transition group-hover:opacity-100">×</button>
              </div>
            ))}
            {gallery.length === 0 && <p className="text-xs text-slate-400">گالری خالی است</p>}
          </div>
        </div>
      </div>

      {/* specs */}
      <div className="rounded-3xl border border-slate-100 bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-black text-ink">مشخصات فنی</h2>
          <button type="button" onClick={() => setSpecs([...specs, { label: "", value: "" }])} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-200">+ افزودن مشخصه</button>
        </div>
        <div className="space-y-2">
          {specs.map((s, i) => (
            <div key={i} className="flex gap-2">
              <input value={s.label} onChange={(e) => { const n = [...specs]; n[i] = { ...n[i], label: e.target.value }; setSpecs(n); }} placeholder="عنوان (مثلاً رم)" className={inputCls} />
              <input value={s.value} onChange={(e) => { const n = [...specs]; n[i] = { ...n[i], value: e.target.value }; setSpecs(n); }} placeholder="مقدار" className={inputCls} />
              <button type="button" onClick={() => setSpecs(specs.filter((_, idx) => idx !== i))} className="shrink-0 grid h-10 w-10 place-items-center rounded-xl bg-rose-50 text-rose-500 hover:bg-rose-100">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
              </button>
            </div>
          ))}
          {specs.length === 0 && <p className="text-xs text-slate-400">مشخصه‌ای اضافه نشده</p>}
        </div>
      </div>

      {/* actions */}
      <div className="flex gap-3">
        <button type="submit" disabled={saving} className="flex-1 rounded-2xl bg-gradient-to-l from-brand-600 to-fuchsia-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand-500/30 transition hover:opacity-90 disabled:opacity-50">
          {saving ? "در حال ذخیره..." : isEdit ? "ذخیره تغییرات" : "ایجاد محصول"}
        </button>
        <button type="button" onClick={() => router.back()} className="rounded-2xl border border-slate-200 px-6 py-3.5 text-sm font-bold text-slate-600 hover:bg-slate-50">انصراف</button>
      </div>

      <MediaPicker
        open={pickerTarget !== null}
        onClose={() => setPickerTarget(null)}
        onSelect={(url) => {
          if (pickerTarget === "image") set("image", url);
          else if (pickerTarget === "gallery") setGallery([...gallery, url]);
        }}
      />
    </form>
  );
}

function Field({ label, full, children }: { label: string; full?: boolean; children: React.ReactNode }) {
  return (
    <label className={`block ${full ? "sm:col-span-2 lg:col-span-4" : ""}`}>
      <span className="mb-2 block text-sm font-bold text-slate-700">{label}</span>
      {children}
    </label>
  );
}

export { COLORS };
