"use client";

import { useEffect, useState } from "react";
import { useStore } from "@/components/store-provider";
import { faNum, formatDate } from "@/lib/format";

type ReviewItem = {
  id: number;
  productId: number;
  name: string;
  rating: number;
  comment: string;
  createdAt: string;
};

export function ReviewsManager() {
  const { pushToast } = useStore();
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Record<number, string>>({});

  const load = async () => {
    setLoading(true);
    const [revRes, prodRes] = await Promise.all([
      fetch("/api/admin/reviews").then((r) => r.json()),
      fetch("/api/admin/products").then((r) => r.json()),
    ]);
    setReviews(Array.isArray(revRes) ? revRes : []);
    const map: Record<number, string> = {};
    if (Array.isArray(prodRes)) prodRes.forEach((p: { id: number; name: string }) => (map[p.id] = p.name));
    setProducts(map);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const del = async (r: ReviewItem) => {
    if (!confirm("حذف این نظر؟")) return;
    const res = await fetch(`/api/admin/reviews/${r.id}`, { method: "DELETE" });
    if (res.ok) {
      pushToast("نظر حذف شد", "success");
      setReviews((prev) => prev.filter((x) => x.id !== r.id));
    }
  };

  if (loading) return <p className="py-16 text-center text-sm text-slate-400">در حال بارگذاری...</p>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-black text-ink">نظرات</h1>
        <p className="mt-1 text-sm text-slate-500">{faNum(reviews.length)} نظر کاربران</p>
      </div>

      {reviews.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-200 py-16 text-center">
          <p className="text-4xl">⭐</p>
          <p className="mt-2 text-sm text-slate-400">نظری وجود ندارد</p>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {reviews.map((r) => (
            <div key={r.id} className="rounded-3xl border border-slate-100 bg-white p-5">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-fuchsia-500 font-bold text-white">{r.name.charAt(0)}</span>
                  <div>
                    <p className="text-sm font-bold text-slate-800">{r.name}</p>
                    <p className="text-xs text-slate-400">{formatDate(r.createdAt)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1" dir="ltr">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className={i < r.rating ? "text-amber-400" : "text-slate-200"}>★</span>
                  ))}
                </div>
              </div>
              {products[r.productId] && (
                <p className="mt-3 inline-block rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">📦 {products[r.productId]}</p>
              )}
              <p className="mt-2 text-sm leading-7 text-slate-600">{r.comment}</p>
              <button onClick={() => del(r)} className="mt-3 flex items-center gap-1 text-xs font-bold text-rose-500 hover:text-rose-600">
                <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" /></svg>
                حذف نظر
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
