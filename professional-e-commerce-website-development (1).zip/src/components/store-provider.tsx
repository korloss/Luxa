"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import type { ReactNode } from "react";

export type CartItem = {
  id: number;
  slug: string;
  name: string;
  price: number;
  image: string;
  qty: number;
};

export type Toast = {
  id: number;
  message: string;
  type: "success" | "info" | "error";
};

type StoreContextValue = {
  cart: CartItem[];
  wishlist: number[];
  cartOpen: boolean;
  toasts: Toast[];
  addToCart: (item: Omit<CartItem, "qty">, qty?: number) => void;
  removeFromCart: (id: number) => void;
  updateQty: (id: number, qty: number) => void;
  clearCart: () => void;
  toggleWishlist: (id: number) => void;
  inWishlist: (id: number) => boolean;
  setCartOpen: (open: boolean) => void;
  cartCount: number;
  cartTotal: number;
  pushToast: (message: string, type?: Toast["type"]) => void;
  freeShipThreshold: number;
  shippingFee: number;
};

const StoreContext = createContext<StoreContextValue | null>(null);

const CART_KEY = "luxa_cart_v1";
const WISH_KEY = "luxa_wishlist_v1";

export function StoreProvider({
  children,
  freeShipThreshold,
  shippingFee,
}: {
  children: ReactNode;
  freeShipThreshold: number;
  shippingFee: number;
}) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const rawCart = localStorage.getItem(CART_KEY);
      const rawWish = localStorage.getItem(WISH_KEY);
      if (rawCart) setCart(JSON.parse(rawCart));
      if (rawWish) setWishlist(JSON.parse(rawWish));
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, hydrated]);

  useEffect(() => {
    if (hydrated) localStorage.setItem(WISH_KEY, JSON.stringify(wishlist));
  }, [wishlist, hydrated]);

  const pushToast = useCallback(
    (message: string, type: Toast["type"] = "success") => {
      const id = Date.now() + Math.random();
      setToasts((prev) => [...prev, { id, message, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 2800);
    },
    [],
  );

  const addToCart = useCallback(
    (item: Omit<CartItem, "qty">, qty = 1) => {
      setCart((prev) => {
        const existing = prev.find((i) => i.id === item.id);
        if (existing) {
          return prev.map((i) =>
            i.id === item.id ? { ...i, qty: i.qty + qty } : i,
          );
        }
        return [...prev, { ...item, qty }];
      });
      pushToast(`${item.name} به سبد اضافه شد`, "success");
    },
    [pushToast],
  );

  const removeFromCart = useCallback((id: number) => {
    setCart((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const updateQty = useCallback((id: number, qty: number) => {
    setCart((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, qty: Math.max(0, qty) } : i))
        .filter((i) => i.qty > 0),
    );
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback(
    (id: number) => {
      setWishlist((prev) => {
        if (prev.includes(id)) {
          return prev.filter((x) => x !== id);
        }
        pushToast("به علاقه‌مندی‌ها اضافه شد", "info");
        return [...prev, id];
      });
    },
    [pushToast],
  );

  const inWishlist = useCallback(
    (id: number) => wishlist.includes(id),
    [wishlist],
  );

  const cartCount = useMemo(
    () => cart.reduce((sum, i) => sum + i.qty, 0),
    [cart],
  );
  const cartTotal = useMemo(
    () => cart.reduce((sum, i) => sum + i.qty * i.price, 0),
    [cart],
  );

  const value: StoreContextValue = {
    cart,
    wishlist,
    cartOpen,
    toasts,
    addToCart,
    removeFromCart,
    updateQty,
    clearCart,
    toggleWishlist,
    inWishlist,
    setCartOpen,
    cartCount,
    cartTotal,
    pushToast,
    freeShipThreshold,
    shippingFee,
  };

  return (
    <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
