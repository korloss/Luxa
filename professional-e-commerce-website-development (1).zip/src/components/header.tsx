"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useStore } from "@/components/store-provider";
import { DEPARTMENTS } from "@/db/schema";
import type { Category, Setting } from "@/db/schema";
import { faNum } from "@/lib/format";

export function Header({
  categories,
  settings,
}: {
  categories: Category[];
  settings?: Setting;
}) {
  const { cartCount, wishlist, setCartOpen } = useStore();
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [q, setQ] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [dept, setDept] = useState(searchParams.get("dept") || "tech");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setDept(searchParams.get("dept") || "tech");
  }, [pathname, searchParams]);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(`/shop?q=${encodeURIComponent(q.trim())}&dept=${dept}`);
  };

  const deptCats = categories.filter((c) => c.department === dept);
  const currentDept = DEPARTMENTS.find((d) => d.id === dept) ?? DEPARTMENTS[0];

  return (
    <header className="sticky top-0 z-40">
      {/* announcement */}
      <div className="bg-ink text-white">
        <div className="mx-auto flex max-w-7xl items-center justify-center gap-2 px-4 py-2 text-center text-xs">
          <span className="animate-pulse">🚚</span>
          <span>{settings?.announcementText ?? "ارسال رایگان برای سفارش‌های بالا • ضمانت اصالت کالا"}</span>
        </div>
      </div>

      {/* main bar */}
      <div className={`border-b transition-all duration-300 ${scrolled ? "glass border-slate-200/70 shadow-sm" : "border-transparent bg-white"}`}>
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
          {/* mobile menu btn */}
          <button onClick={() => setMenuOpen(true)} className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 text-slate-700 lg:hidden" aria-label="منو">
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h18M3 12h18M3 18h18" /></svg>
          </button>

          {/* logo */}
          <Link href="/" className="flex shrink-0 items-center gap-2">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-fuchsia-500 text-lg font-black text-white shadow-lg shadow-brand-500/30">L</span>
            <span className="text-xl font-black tracking-tight text-ink">لوکسا</span>
          </Link>

          {/* search */}
          <form onSubmit={submitSearch} className="relative mx-2 hidden flex-1 md:block">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجوی محصول، برند یا دسته‌بندی..." className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-2.5 pr-11 pl-4 text-sm outline-none transition focus:border-brand-400 focus:bg-white focus:ring-4 focus:ring-brand-100" />
            <svg viewBox="0 0 24 24" className="absolute right-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
          </form>

          {/* actions */}
          <div className="mr-auto flex items-center gap-1.5">
            <Link href="/wishlist" className="relative grid h-10 w-10 place-items-center rounded-xl text-slate-700 transition hover:bg-slate-100" aria-label="علاقه‌مندی‌ها">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 21s-7.5-4.6-10-9.3C.6 8.4 2.2 5 5.5 5c2 0 3.3 1.1 4.5 2.7C11.2 6.1 12.5 5 14.5 5 17.8 5 19.4 8.4 18 11.7 15.5 16.4 12 21 12 21z" /></svg>
              {wishlist.length > 0 && (<span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">{faNum(wishlist.length)}</span>)}
            </Link>
            <button onClick={() => setCartOpen(true)} className="relative grid h-10 w-10 place-items-center rounded-xl text-slate-700 transition hover:bg-slate-100" aria-label="سبد خرید">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" /><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6" /></svg>
              {cartCount > 0 && (<span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-brand-600 px-1 text-[10px] font-bold text-white">{faNum(cartCount)}</span>)}
            </button>
            <Link href="/admin" className="hidden rounded-xl border border-slate-200 px-3 py-2.5 text-sm font-bold text-slate-700 transition hover:bg-slate-100 sm:block" title="پنل مدیریت">⚙️ مدیریت</Link>
            <Link href="/shop" className="hidden rounded-xl bg-ink px-4 py-2.5 text-sm font-bold text-white transition hover:bg-brand-700 sm:block">فروشگاه</Link>
          </div>
        </div>

        {/* mobile search */}
        <div className="px-4 pb-3 md:hidden">
          <form onSubmit={submitSearch} className="relative">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو..." className="w-full rounded-2xl border border-slate-200 bg-slate-50 py-2.5 pr-11 pl-4 text-sm outline-none focus:border-brand-400 focus:bg-white" />
            <svg viewBox="0 0 24 24" className="absolute right-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></svg>
          </form>
        </div>
      </div>

      {/* department + category nav */}
      <nav className="hidden border-b border-slate-100 bg-white/80 backdrop-blur lg:block">
        <div className="mx-auto flex max-w-7xl items-center gap-1 px-4 py-1.5">
          {/* department switch */}
          <div className="flex items-center rounded-xl bg-slate-100 p-0.5">
            {DEPARTMENTS.map((d) => (
              <button
                key={d.id}
                onClick={() => setDept(d.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${dept === d.id ? "bg-white text-brand-700 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
              >
                {d.icon} {d.short}
              </button>
            ))}
          </div>
          <div className="mx-1 h-5 w-px bg-slate-200" />
          <Link href={`/shop?dept=${dept}`} className="rounded-lg px-3 py-2 text-sm font-bold text-slate-700 transition hover:bg-brand-50 hover:text-brand-700">همه</Link>
          {deptCats.map((c) => (
            <Link key={c.id} href={`/shop?cat=${c.slug}&dept=${dept}`} className="rounded-lg px-3 py-2 text-sm text-slate-600 transition hover:bg-brand-50 hover:text-brand-700">{c.icon} {c.name}</Link>
          ))}
          <Link href="/shop?dept=food" className="mr-auto rounded-lg px-3 py-2 text-sm font-bold text-emerald-600 transition hover:bg-emerald-50">🛒 سوپرمارکت</Link>
        </div>
      </nav>

      {/* mobile drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={() => setMenuOpen(false)} />
          <div className="animate-fade-up absolute right-0 top-0 h-full w-72 overflow-y-auto bg-white p-5 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <span className="text-lg font-black text-ink">منو</span>
              <button onClick={() => setMenuOpen(false)} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200" aria-label="بستن">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
              </button>
            </div>
            {/* dept switch mobile */}
            <div className="mb-3 flex gap-2">
              {DEPARTMENTS.map((d) => (
                <button key={d.id} onClick={() => setDept(d.id)} className={`flex-1 rounded-xl px-3 py-2 text-xs font-bold transition ${dept === d.id ? "bg-brand-600 text-white" : "bg-slate-100 text-slate-600"}`}>{d.icon} {d.short}</button>
              ))}
            </div>
            <div className="flex flex-col gap-1">
              <Link href="/" className="rounded-xl px-3 py-2.5 font-bold text-slate-800 hover:bg-slate-100">خانه</Link>
              <Link href={`/shop?dept=${dept}`} className="rounded-xl px-3 py-2.5 font-bold text-slate-800 hover:bg-slate-100">همه محصولات {currentDept.short}</Link>
              <Link href="/wishlist" className="rounded-xl px-3 py-2.5 text-slate-700 hover:bg-slate-100">علاقه‌مندی‌ها</Link>
              <Link href="/cart" className="rounded-xl px-3 py-2.5 text-slate-700 hover:bg-slate-100">سبد خرید</Link>
              <Link href="/track" className="rounded-xl px-3 py-2.5 text-slate-700 hover:bg-slate-100">پیگیری سفارش</Link>
              <Link href="/admin" className="rounded-xl px-3 py-2.5 text-slate-700 hover:bg-slate-100">⚙️ پنل مدیریت</Link>
              <div className="my-2 h-px bg-slate-100" />
              {deptCats.map((c) => (
                <Link key={c.id} href={`/shop?cat=${c.slug}&dept=${dept}`} className="rounded-xl px-3 py-2.5 text-slate-700 hover:bg-brand-50 hover:text-brand-700">{c.icon} {c.name}</Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
