"use client";

import Link from "next/link";
import { useState } from "react";
import type { Category, Setting } from "@/db/schema";

export function Footer({
  categories,
  settings,
}: {
  categories: Category[];
  settings?: Setting;
}) {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  return (
    <footer className="mt-20 bg-ink text-slate-300">
      {/* newsletter */}
      <div className="border-b border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-6 px-4 py-12 text-center md:flex-row md:justify-between md:text-right">
          <div>
            <h3 className="text-2xl font-black text-white">
              عضو خبرنامه لوکسا شوید ✨
            </h3>
            <p className="mt-2 text-sm text-slate-400">
              از جدیدترین تخفیف‌ها و محصولات زودتر از همه باخبر شوید
            </p>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (email.trim()) {
                setDone(true);
                setEmail("");
                setTimeout(() => setDone(false), 3000);
              }
            }}
            className="flex w-full max-w-md gap-2"
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="ایمیل شما"
              className="flex-1 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-slate-500 outline-none focus:border-brand-400"
            />
            <button
              type="submit"
              className="rounded-2xl bg-gradient-to-l from-brand-500 to-fuchsia-500 px-6 py-3 text-sm font-bold text-white transition hover:opacity-90"
            >
              {done ? "ثبت شد ✓" : "عضویت"}
            </button>
          </form>
        </div>
      </div>

      {/* links */}
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 py-12 md:grid-cols-4">
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-fuchsia-500 text-lg font-black text-white">
              L
            </span>
            <span className="text-xl font-black text-white">لوکسا</span>
          </div>
          <p className="mt-4 text-sm leading-7 text-slate-400">
            فروشگاه اینترنتی لوکسا، مرجع تخصصی محصولات تکنولوژی با ضمانت اصالت
            کالا و ارسال سریع به سراسر کشور.
          </p>
          <div className="mt-4 flex gap-2">
            {["📷", "✈️", "📺", "💬"].map((s, i) => (
              <span
                key={i}
                className="grid h-9 w-9 place-items-center rounded-xl bg-white/5 text-base transition hover:bg-white/10"
              >
                {s}
              </span>
            ))}
          </div>
        </div>

        <div>
          <h4 className="mb-4 font-bold text-white">دسته‌بندی‌ها</h4>
          <ul className="space-y-2.5 text-sm">
            {categories.map((c) => (
              <li key={c.id}>
                <Link
                  href={`/shop?cat=${c.slug}`}
                  className="text-slate-400 transition hover:text-brand-300"
                >
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-bold text-white">دسترسی سریع</h4>
          <ul className="space-y-2.5 text-sm">
            <li><Link href="/shop" className="text-slate-400 transition hover:text-brand-300">همه محصولات</Link></li>
            <li><Link href="/wishlist" className="text-slate-400 transition hover:text-brand-300">علاقه‌مندی‌ها</Link></li>
            <li><Link href="/cart" className="text-slate-400 transition hover:text-brand-300">سبد خرید</Link></li>
            <li><Link href="/track" className="text-slate-400 transition hover:text-brand-300">پیگیری سفارش</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-bold text-white">پشتیبانی</h4>
          <ul className="space-y-2.5 text-sm text-slate-400">
            <li className="flex items-center gap-2"><span>📞</span> {settings?.contactPhone ?? "۰۲۱-۹۱۰۰۰۰۰۰"}</li>
            <li className="flex items-center gap-2"><span>✉️</span> {settings?.contactEmail ?? "support@luxa.ir"}</li>
            <li className="flex items-center gap-2"><span>📍</span> {settings?.contactAddress ?? "تهران، خیابان ولیعصر"}</li>
            <li className="flex items-center gap-2"><span>🕐</span> شنبه تا پنجشنبه، ۹ تا ۲۱</li>
          </ul>
        </div>
      </div>

      {/* trust badges */}
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-8 gap-y-3 px-4 py-5 text-xs text-slate-400">
          <span className="flex items-center gap-2">🛡️ پرداخت امن</span>
          <span className="flex items-center gap-2">✅ ضمانت اصالت</span>
          <span className="flex items-center gap-2">🚚 ارسال سریع</span>
          <span className="flex items-center gap-2">↩️ بازگشت ۷ روزه</span>
          <span className="flex items-center gap-2">🎧 پشتیبانی ۲۴/۷</span>
        </div>
      </div>

      <div className="border-t border-white/10 py-5 text-center text-xs text-slate-500">
        © {new Intl.NumberFormat("fa-IR").format(1404)} لوکسا — تمامی حقوق محفوظ
        است. ساخته‌شده با ❤️
      </div>
    </footer>
  );
}
