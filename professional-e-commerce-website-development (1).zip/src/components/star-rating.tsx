"use client";

export function StarRating({
  rating,
  size = "sm",
  showValue = false,
}: {
  rating: number;
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
}) {
  const sizes = {
    sm: "w-3.5 h-3.5",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  } as const;
  const full = Math.floor(rating);
  const hasHalf = rating - full >= 0.5;

  return (
    <div className="flex items-center gap-0.5" dir="ltr">
      {[0, 1, 2, 3, 4].map((i) => {
        const isFull = i < full;
        const isHalf = i === full && hasHalf;
        return (
          <div key={i} className={`relative ${sizes[size]}`}>
            <Star className={`${sizes[size]} text-slate-200`} />
            {(isFull || isHalf) && (
              <div
                className={`absolute inset-0 overflow-hidden ${
                  isHalf ? "w-1/2" : "w-full"
                }`}
              >
                <Star className={`${sizes[size]} text-amber-400`} />
              </div>
            )}
          </div>
        );
      })}
      {showValue && (
        <span className="mr-1 text-xs font-bold text-amber-500">
          {new Intl.NumberFormat("fa-IR", {
            minimumFractionDigits: 1,
            maximumFractionDigits: 1,
          }).format(rating)}
        </span>
      )}
    </div>
  );
}

function Star({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M12 2l2.95 6.18 6.8.74-5.06 4.6 1.4 6.7L12 17.9 5.91 20.9l1.4-6.7L2.25 9.6l6.8-.74L12 2z" />
    </svg>
  );
}
