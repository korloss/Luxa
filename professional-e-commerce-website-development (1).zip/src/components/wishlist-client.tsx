"use client";

import Link from "next/link";
import { useStore } from "@/components/store-provider";
import { ProductCard } from "@/components/product-card";
import type { Product } from "@/db/schema";

export function WishlistClient({ products }: { products: Product[] }) {
  const { wishlist } = useStore();
  const items = products.filter((p) => wishlist.includes(p.id));

  if (items.length === 0) {
    return (
      <div className="mx-auto flex max-w-2xl flex-col items-center gap-5 px-4 py-24 text-center">
        <div className="grid h-28 w-28 place-items-center rounded-full bg-rose-50 text-6xl">
          ❤️
        </div>
        <h1 className="text-2xl font-black text-ink">لیست علاقه‌مندی‌ها خالی است</h1>
        <p className="text-sm text-slate-500">
          محصولات مورد علاقه را با ❤️ ذخیره کنید تا اینجا ببینید.
        </p>
        <Link
          href="/shop"
          className="rounded-2xl bg-ink px-7 py-3.5 text-sm font-bold text-white transition hover:bg-brand-700"
        >
          کاوش فروشگاه
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="mb-6 flex items-center gap-2">
        <h1 className="text-2xl font-black text-ink sm:text-3xl">علاقه‌مندی‌های من</h1>
        <span className="rounded-full bg-rose-50 px-3 py-1 text-sm font-bold text-rose-600">
          {items.length} محصول
        </span>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {items.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}
