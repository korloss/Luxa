import { db } from "@/db";
import { categories, products, reviews, settings } from "@/db/schema";
import { inArray } from "drizzle-orm";

const IMG = {
  phone1: "https://images.pexels.com/photos/18311092/pexels-photo-18311092.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  phone2: "https://images.pexels.com/photos/14979013/pexels-photo-14979013.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  laptop1: "https://images.pexels.com/photos/4533076/pexels-photo-4533076.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  laptop2: "https://images.pexels.com/photos/12200696/pexels-photo-12200696.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hp1: "https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  hp2: "https://images.pexels.com/photos/4526407/pexels-photo-4526407.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  speaker: "https://images.pexels.com/photos/29581125/pexels-photo-29581125.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  watch1: "https://images.pexels.com/photos/31541678/pexels-photo-31541678.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  watch2: "https://images.pexels.com/photos/12564670/pexels-photo-12564670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  cam1: "https://images.pexels.com/photos/33037156/pexels-photo-33037156.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  cam2: "https://images.pexels.com/photos/16013967/pexels-photo-16013967.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  cam3: "https://images.pexels.com/photos/10416279/pexels-photo-10416279.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  kb1: "https://images.pexels.com/photos/18311171/pexels-photo-18311171.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  kb2: "https://images.pexels.com/photos/12877898/pexels-photo-12877898.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  kb3: "https://images.pexels.com/photos/8219211/pexels-photo-8219211.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  tablet: "https://images.pexels.com/photos/18205642/pexels-photo-18205642.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  setup: "https://images.pexels.com/photos/18311089/pexels-photo-18311089.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  // food
  fruit: "https://images.pexels.com/photos/9070106/pexels-photo-9070106.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  pumpkin: "https://images.pexels.com/photos/7599097/pexels-photo-7599097.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  milk1: "https://images.pexels.com/photos/18258533/pexels-photo-18258533.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  milk2: "https://images.pexels.com/photos/36183642/pexels-photo-36183642.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  cheese1: "https://images.pexels.com/photos/10165775/pexels-photo-10165775.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  cheese2: "https://images.pexels.com/photos/8743918/pexels-photo-8743918.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  eggs: "https://images.pexels.com/photos/4394258/pexels-photo-4394258.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  pasta: "https://images.pexels.com/photos/16620746/pexels-photo-16620746.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  bread1: "https://images.pexels.com/photos/18647862/pexels-photo-18647862.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  bread2: "https://images.pexels.com/photos/30804068/pexels-photo-30804068.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  drink1: "https://images.pexels.com/photos/3651044/pexels-photo-3651044.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  drink2: "https://images.pexels.com/photos/34270746/pexels-photo-34270746.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  walnut: "https://images.pexels.com/photos/37309469/pexels-photo-37309469.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  choco: "https://images.pexels.com/photos/37857736/pexels-photo-37857736.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
};

const spec = (label: string, value: string) => ({ label, value });

const categoryData = [
  // tech
  { name: "موبایل و تبلت", slug: "mobile", icon: "📱", color: "from-indigo-500 to-violet-600", description: "جدیدترین گوشی‌ها و تبلت‌های هوشمند", department: "tech" },
  { name: "لپ‌تاپ", slug: "laptop", icon: "💻", color: "from-sky-500 to-blue-600", description: "لپ‌تاپ‌های اداری، خلاقانه و گیمینگ", department: "tech" },
  { name: "هدفون و اسپیکر", slug: "audio", icon: "🎧", color: "from-fuchsia-500 to-pink-600", description: "تجربه‌ای بی‌نظیر از صدا", department: "tech" },
  { name: "ساعت هوشمند", slug: "watch", icon: "⌚", color: "from-emerald-500 to-teal-600", description: "هوشمندی و سلامت روی مچ شما", department: "tech" },
  { name: "دوربین", slug: "camera", icon: "📷", color: "from-amber-500 to-orange-600", description: "ثبت لحظات با بالاترین کیفیت", department: "tech" },
  { name: "لوازم جانبی", slug: "accessories", icon: "⌨️", color: "from-rose-500 to-red-600", description: "تکمیل‌کننده‌ی تجربه‌ی دیجیتال شما", department: "tech" },
  // food
  { name: "میوه و سبزیجات", slug: "fruits", icon: "🍎", color: "from-red-500 to-rose-600", description: "تازه‌ترین میوه‌ها و سبزیجات روز", department: "food" },
  { name: "لبنیات", slug: "dairy", icon: "🥛", color: "from-sky-400 to-cyan-600", description: "شیر، ماست، پنیر و لبنیات تازه", department: "food" },
  { name: "گوشت و پروتئین", slug: "protein", icon: "🥩", color: "from-rose-400 to-red-600", description: "گوشت، مرغ، ماهی و تخم‌مرغ", department: "food" },
  { name: "نان و غلات", slug: "grains", icon: "🍞", color: "from-amber-400 to-yellow-600", description: "نان، برنج، ماکارونی و حبوبات", department: "food" },
  { name: "نوشیدنی", slug: "beverage", icon: "🥤", color: "from-teal-400 to-emerald-600", description: "نوشیدنی‌های خنک و گرم", department: "food" },
  { name: "تنقلات", slug: "snacks", icon: "🍫", color: "from-orange-400 to-amber-600", description: "خشکبار، شکلات و تنقلات", department: "food" },
];

type SeedProduct = {
  name: string; slug: string; description: string; brand: string;
  price: number; oldPrice?: number; image: string; gallery: string[];
  specs: { label: string; value: string }[]; rating: number; reviewCount: number;
  stock: number; badge?: string; category: string; featured: boolean; department: "tech" | "food";
};

const productData: SeedProduct[] = [
  // ===== TECH =====
  { name: "گوشی هوشمند نوا اليترا", slug: "nova-ultra", description: "گوشی پرچمدار نوا با نمایشگر AMOLED ۱۲۰ هرتز، دوربین ۲۰۰ مگاپیکسلی و پردازنده‌ی پرقدرت. تجربه‌ای بی‌نقص برای کار، بازی و عکاسی در نور ضعیف.", brand: "Nova", price: 48000000, oldPrice: 55000000, image: IMG.phone1, gallery: [IMG.phone1, IMG.phone2, IMG.setup], specs: [spec("حافظه داخلی", "۲۵۶ گیگابایت"), spec("رم", "۱۲ گیگابایت"), spec("نمایشگر", "۶.۷ اینچ AMOLED"), spec("باتری", "۵۰۰۰ میلی‌آمپر")], rating: 4.8, reviewCount: 214, stock: 15, badge: "پرفروش", category: "mobile", featured: true, department: "tech" },
  { name: "گوشی میان‌رده نوا اج", slug: "nova-edge", description: "گوشی خوش‌قیمت با طراحی شیک و عملکرد قابل اعتماد برای استفاده‌ی روزمره. باتری طولانی و شارژ سریع.", brand: "Nova", price: 18500000, image: IMG.phone2, gallery: [IMG.phone2, IMG.phone1], specs: [spec("حافظه داخلی", "۱۲۸ گیگابایت"), spec("رم", "۸ گیگابایت"), spec("نمایشگر", "۶.۵ اینچ"), spec("باتری", "۴۸۰۰ میلی‌آمپر")], rating: 4.5, reviewCount: 132, stock: 30, badge: "جدید", category: "mobile", featured: false, department: "tech" },
  { name: "تبلت پرو ۱۲ اینچ", slug: "tab-pro-12", description: "تبلت قدرتمند با نمایشگر ۱۲ اینچی و قلم پشتیبان، ایده‌آل برای خلاقیت، طراحی و تماشای فیلم.", brand: "Lumina", price: 58000000, oldPrice: 64000000, image: IMG.tablet, gallery: [IMG.tablet, IMG.setup], specs: [spec("حافظه داخلی", "۲۵۶ گیگابایت"), spec("رم", "۸ گیگابایت"), spec("نمایشگر", "۱۲ اینچ"), spec("پشتیبانی قلم", "بله")], rating: 4.7, reviewCount: 88, stock: 12, badge: "محبوب", category: "mobile", featured: true, department: "tech" },
  { name: "لپ‌تاپ اولترابوک پرو ۱۴", slug: "ultrabook-pro-14", description: "اولترابوک فوق‌باریک با بدنه‌ی آلومینیومی، پردازنده‌ی نسل جدید و باتری ۱۸ ساعته.", brand: "Zen", price: 72000000, image: IMG.laptop1, gallery: [IMG.laptop1, IMG.laptop2, IMG.setup], specs: [spec("پردازنده", "Core i7 نسل ۱۳"), spec("رم", "۱۶ گیگابایت"), spec("حافظه", "۵۱۲ گیگ SSD"), spec("نمایشگر", "۱۴ اینچ 2.8K")], rating: 4.9, reviewCount: 76, stock: 8, badge: "ویژه", category: "laptop", featured: true, department: "tech" },
  { name: "لپ‌تاپ گیمینگ تایتان", slug: "gaming-titan", description: "غول بازی با کارت گرافیک قدرتمند، نمایشگر ۱۶۵ هرتز و سیستم خنک‌کننده‌ی پیشرفته.", brand: "Rogue", price: 95000000, oldPrice: 109000000, image: IMG.laptop2, gallery: [IMG.laptop2, IMG.kb2], specs: [spec("پردازنده", "Core i9"), spec("کارت گرافیک", "RTX 4070"), spec("رم", "۳۲ گیگابایت"), spec("نمایشگر", "۱۶ اینچ 165Hz")], rating: 4.7, reviewCount: 54, stock: 6, badge: "تخفیف", category: "laptop", featured: true, department: "tech" },
  { name: "هدفون بی‌سیم ایرو نویز کنسلینگ", slug: "aero-anc-headphones", description: "هدفون روی‌گوشی با حذف نویز فعال، صدای غنی و باتری ۴۰ ساعته.", brand: "Aero", price: 8900000, oldPrice: 12000000, image: IMG.hp1, gallery: [IMG.hp1, IMG.hp2, IMG.speaker], specs: [spec("حذف نویز", "ANC فعال"), spec("باتری", "۴۰ ساعت"), spec("اتصال", "بلوتوث ۵.۳"), spec("وزن", "۲۵۰ گرم")], rating: 4.8, reviewCount: 320, stock: 40, badge: "محبوب", category: "audio", featured: true, department: "tech" },
  { name: "هندزفری بی‌سیم تروبادز پرو", slug: "truebuds-pro", description: "هندزفری واقعاً بی‌سیم با صدای شفاف، حالت شفافیت محیط و محفظه‌ی شارژ بی‌سیم.", brand: "Aero", price: 3200000, image: IMG.hp2, gallery: [IMG.hp2, IMG.hp1], specs: [spec("باتری", "۲۴ ساعت با محفظه"), spec("مقاومت", "IPX5"), spec("اتصال", "بلوتوث ۵.۳"), spec("شارژ", "USB-C و بی‌سیم")], rating: 4.6, reviewCount: 198, stock: 60, badge: "جدید", category: "audio", featured: true, department: "tech" },
  { name: "اسپیکر بلوتوث پرتابل بوم", slug: "boom-portable-speaker", description: "اسپیکر پرتابل با صدای ۳۶۰ درجه، بیس قدرتمند و بدنه‌ی ضدآب.", brand: "Sonic", price: 6500000, oldPrice: 7900000, image: IMG.speaker, gallery: [IMG.speaker, IMG.hp1], specs: [spec("توان", "۳۰ وات"), spec("باتری", "۲۰ ساعت"), spec("مقاومت", "IP67"), spec("اتصال", "بلوتوث ۵.۰")], rating: 4.5, reviewCount: 110, stock: 25, category: "audio", featured: false, department: "tech" },
  { name: "ساعت هوشمند پالس سری ۷", slug: "pulse-watch-7", description: "ساعت هوشمند با نمایشگر همیشه روشن، مانیتورینگ قلب، اکسیژن خون و GPS.", brand: "Pulse", price: 14500000, oldPrice: 18000000, image: IMG.watch1, gallery: [IMG.watch1, IMG.watch2], specs: [spec("نمایشگر", "AMOLED همیشه روشن"), spec("باتری", "۷ روز"), spec("حسگرها", "قلب، اکسیژن، خواب"), spec("مقاومت", "۵ ATM")], rating: 4.7, reviewCount: 240, stock: 18, badge: "محبوب", category: "watch", featured: true, department: "tech" },
  { name: "ساعت هوشمند اسپرت پالس", slug: "pulse-sport", description: "ساعت ورزشی مقاوم با بیش از ۱۰۰ حالت ورزشی و باتری دو هفته‌ای.", brand: "Pulse", price: 7800000, image: IMG.watch2, gallery: [IMG.watch2, IMG.watch1], specs: [spec("باتری", "۱۴ روز"), spec("حالت ورزشی", "۱۰۰+"), spec("مقاومت", "۵ ATM"), spec("GPS", "داخلی")], rating: 4.4, reviewCount: 96, stock: 22, category: "watch", featured: false, department: "tech" },
  { name: "دوربین بدون آینه مایرو ایکس", slug: "mirro-x-camera", description: "دوربین بدون آینه با سنسور فول‌فریم، فیلم‌برداری ۴K ۶۰ فریم و فوکوس خودکار هوشمند.", brand: "Optica", price: 89000000, image: IMG.cam1, gallery: [IMG.cam1, IMG.cam2, IMG.cam3], specs: [spec("سنسور", "فول‌فریم ۲۴ مگاپیکسل"), spec("ویدیو", "4K 60fps"), spec("تثبیت‌کننده", "۵ محوره IBIS"), spec("اتصال", "WiFi و بلوتوث")], rating: 4.9, reviewCount: 64, stock: 5, badge: "ویژه", category: "camera", featured: true, department: "tech" },
  { name: "دوربین دی‌اس‌ال‌آر پرو", slug: "dslr-pro-camera", description: "دوربین دی‌اس‌ال‌آر حرفه‌ای با سرعت کادر بالا و کیفیت تصویر استثنایی.", brand: "Optica", price: 124000000, oldPrice: 138000000, image: IMG.cam2, gallery: [IMG.cam2, IMG.cam1], specs: [spec("سنسور", "فول‌فریم ۴۵ مگاپیکسل"), spec("سرعت", "۱۴ کادر بر ثانیه"), spec("ویدیو", "4K"), spec("مانیتور", "لمسی متحرک")], rating: 4.8, reviewCount: 41, stock: 4, category: "camera", featured: false, department: "tech" },
  { name: "دوربین عکاسی اسنپ ۵۰", slug: "snap-50-camera", description: "دوربین جمع‌و‌جور با کیفیت بالا برای عکاسی روزمره و سفر.", brand: "Optica", price: 67000000, image: IMG.cam3, gallery: [IMG.cam3, IMG.cam2], specs: [spec("سنسور", "APS-C ۲۶ مگاپیکسل"), spec("ویدیو", "4K 30fps"), spec("وزن", "۴۵۰ گرم"), spec("اتصال", "WiFi")], rating: 4.5, reviewCount: 73, stock: 9, badge: "تخفیف", category: "camera", featured: false, department: "tech" },
  { name: "کیبورد مکانیکال RGB", slug: "mech-rgb-keyboard", description: "کیبورد مکانیکال با سوئیچ‌های قابل تعویض، نورپردازی RGB و بدنه‌ی آلومینیومی.", brand: "Click", price: 4200000, oldPrice: 5200000, image: IMG.kb1, gallery: [IMG.kb1, IMG.kb2, IMG.kb3], specs: [spec("نوع سوئیچ", "قرمز مکانیکال"), spec("نورپردازی", "RGB"), spec("اتصال", "سیمی USB-C"), spec("بدنه", "آلومینیوم")], rating: 4.7, reviewCount: 156, stock: 35, badge: "محبوب", category: "accessories", featured: true, department: "tech" },
  { name: "ست کیبورد و موس گیمینگ", slug: "gaming-keyboard-mouse-set", description: "ست کامل گیمینگ شامل کیبورد و موس با حساسیت بالا و نورپردازی هماهنگ.", brand: "Click", price: 5600000, image: IMG.kb2, gallery: [IMG.kb2, IMG.kb1], specs: [spec("موس", "۱۶۰۰۰ DPI"), spec("کیبورد", "ممبرین گیمینگ"), spec("نورپردازی", "RGB"), spec("اتصال", "سیمی")], rating: 4.6, reviewCount: 87, stock: 28, category: "accessories", featured: false, department: "tech" },
  { name: "کیبورد بی‌سیم مینی", slug: "mini-wireless-keyboard", description: "کیبورد فشرده و بی‌سیم با چیدمان ارگونومیک و باتری طولانی.", brand: "Click", price: 2800000, image: IMG.kb3, gallery: [IMG.kb3, IMG.kb1], specs: [spec("اتصال", "بلوتوث"), spec("باتری", "۳ ماه"), spec("چیدمان", "فشرده ۷۵٪"), spec("وزن", "۴۰۰ گرم")], rating: 4.3, reviewCount: 64, stock: 45, badge: "جدید", category: "accessories", featured: false, department: "tech" },
  { name: "ست لوازم جانبی دسکتاپ", slug: "desktop-accessory-bundle", description: "ست کامل لوازم جانبی شامل پایه لپ‌تاپ، هاب و کابل‌های مرتب.", brand: "Click", price: 4900000, image: IMG.setup, gallery: [IMG.setup, IMG.kb2], specs: [spec("پایه لپ‌تاپ", "آلومینیومی"), spec("هاب", "۷ پورت"), spec("کابل", "USB-C"), spec("مواد", "فلزی و ضدخش")], rating: 4.5, reviewCount: 52, stock: 20, category: "accessories", featured: false, department: "tech" },
  // ===== FOOD =====
  { name: "سبد میوه تازه فصلی", slug: "fresh-fruit-basket", description: "ترکیبی از تازه‌ترین میوه‌های فصل، شامل سیب، پرتقال و موز، برداشت‌شده در همان روز.", brand: "باغ لوکسا", price: 285000, oldPrice: 350000, image: IMG.fruit, gallery: [IMG.fruit, IMG.pumpkin], specs: [spec("وزن خالص", "۳ کیلوگرم"), spec("نوع", "ترکیبی فصلی"), spec("نگهداری", "محیط خنک"), spec("مبدا", "باغات شمال")], rating: 4.7, reviewCount: 88, stock: 50, badge: "تازه", category: "fruits", featured: true, department: "food" },
  { name: "کدو سبز ارگانیک", slug: "organic-zucchini", description: "کدو سبز ارگانیک و تازه، بدون سموم، ایده‌آل برای سالاد و پخت‌وپز سالم.", brand: "مزرعه سبز", price: 78000, image: IMG.pumpkin, gallery: [IMG.pumpkin, IMG.fruit], specs: [spec("وزن", "۱ کیلوگرم"), spec("نوع کشت", "ارگانیک"), spec("تازگی", "برداشت یک‌روزه")], rating: 4.4, reviewCount: 34, stock: 80, category: "fruits", featured: false, department: "food" },
  { name: "شیر تازه پاستوریزه", slug: "fresh-milk", description: "شیر گاو تازه و پاستوریزه، غنی از کلسیم و ویتامین D، بدون افزودنی.", brand: "گاوداری پاک", price: 95000, oldPrice: 110000, image: IMG.milk1, gallery: [IMG.milk1, IMG.milk2], specs: [spec("حجم", "۱ لیتری"), spec("چربی", "۳.۲٪"), spec("نوع", "پاستوریزه"), spec("نگهداری", "یخچال")], rating: 4.6, reviewCount: 142, stock: 60, badge: "تازه", category: "dairy", featured: true, department: "food" },
  { name: "شیر پرچرب روستایی", slug: "full-fat-milk", description: "شیر پرچرب طبیعی و روستایی با طعم غنی و خامه‌ای، بسته‌بندی شیشه‌ای.", brand: "گاوداری پاک", price: 120000, image: IMG.milk2, gallery: [IMG.milk2, IMG.milk1], specs: [spec("حجم", "۹۵۰ میلی‌لیتر"), spec("چربی", "۶٪"), spec("بسته‌بندی", "شیشه")], rating: 4.8, reviewCount: 67, stock: 40, category: "dairy", featured: false, department: "food" },
  { name: "پنیر سفید کم‌چرب", slug: "low-fat-cheese", description: "پنیر سفید خانگی و کم‌چرب، تازه و خوش‌طعم، مناسب صبحانه‌ی سالم.", brand: "لبنیات البرز", price: 215000, oldPrice: 260000, image: IMG.cheese1, gallery: [IMG.cheese1, IMG.cheese2], specs: [spec("وزن", "۴۰۰ گرم"), spec("چربی", "کم‌چرب"), spec("نوع", "سفید خانگی")], rating: 4.5, reviewCount: 95, stock: 55, category: "dairy", featured: true, department: "food" },
  { name: "پنیر پلاتر مخلوط", slug: "mixed-cheese-platter", description: "سینی پنیرهای متنوع برای مهمانی و پذیرایی، شامل انواع پنیرهای خاص.", brand: "لبنیات البرز", price: 480000, image: IMG.cheese2, gallery: [IMG.cheese2, IMG.cheese1], specs: [spec("وزن", "۸۰۰ گرم"), spec("نوع", "ترکیبی"), spec("مناسب", "مهمانی")], rating: 4.6, reviewCount: 41, stock: 25, badge: "ویژه", category: "dairy", featured: false, department: "food" },
  { name: "تخم‌مرغ بومی تازه", slug: "free-range-eggs", description: "تخم‌مرغ بومی و ارگانیک با زرده‌ی پررنگ، غنی از امگا ۳ و پروتئین.", brand: "مرغداری طبیعت", price: 145000, image: IMG.eggs, gallery: [IMG.eggs], specs: [spec("تعداد", "۳۰ عدد"), spec("نوع", "بومی ارگانیک"), spec("وزن", "متوسط")], rating: 4.7, reviewCount: 120, stock: 70, badge: "محبوب", category: "protein", featured: true, department: "food" },
  { name: "ماکارونی پرمیوم", slug: "premium-pasta", description: "ماکارونی باکیفیت از گندم دوروم، بافت محکم و طعم عالی، در چند شکل متنوع.", brand: "آسیاب طلایی", price: 62000, oldPrice: 78000, image: IMG.pasta, gallery: [IMG.pasta, IMG.bread1], specs: [spec("وزن", "۵۰۰ گرم"), spec("نوع آرد", "دوروم"), spec("پخت", "۸ دقیقه")], rating: 4.3, reviewCount: 58, stock: 90, category: "grains", featured: false, department: "food" },
  { name: "نان سنگک سنتی", slug: "traditional-sangak", description: "نان سنگک سنتی و تازه‌پز روی سنگ، سبوس‌دار و مقوی، پخته‌شده در تنور.", brand: "نانوایی سنتی", price: 45000, image: IMG.bread1, gallery: [IMG.bread1, IMG.bread2], specs: [spec("وزن", "حدود ۴۰۰ گرم"), spec("نوع", "سنگک سبوس‌دار"), spec("تازگی", "روز پخت")], rating: 4.6, reviewCount: 76, stock: 65, badge: "تازه", category: "grains", featured: true, department: "food" },
  { name: "نان روستایی هنری", slug: "artisan-bread", description: "نان روستایی و هنری با خمیر ترش، پوسته‌ی ترد و بافت نرم.", brand: "نانوایی سنتی", price: 88000, image: IMG.bread2, gallery: [IMG.bread2, IMG.bread1], specs: [spec("وزن", "۵۰۰ گرم"), spec("خمیر", "ترش طبیعی"), spec("پخته", "روی سنگ")], rating: 4.5, reviewCount: 44, stock: 38, category: "grains", featured: false, department: "food" },
  { name: "لیموناد تازه دست‌ساز", slug: "fresh-lemonade", description: "لیموناد خنک و طبیعی با لیموترش تازه و نعناع، بدون شکر مصنوعی.", brand: "نوشیدنی بار", price: 110000, oldPrice: 140000, image: IMG.drink1, gallery: [IMG.drink1, IMG.drink2], specs: [spec("حجم", "۵۰۰ میلی‌لیتر"), spec("نوع", "طبیعی"), spec("شکر", "بدون مصنوعی")], rating: 4.4, reviewCount: 63, stock: 48, badge: "تخفیف", category: "beverage", featured: true, department: "food" },
  { name: "آبمیوه طبیعی چندگانه", slug: "natural-juice-set", description: "ست آبمیوه‌های طبیعی ۱۰۰٪، شامل پرتقال، انار و هویج، بدون قند افزوده.", brand: "نوشیدنی بار", price: 195000, image: IMG.drink2, gallery: [IMG.drink2, IMG.drink1], specs: [spec("حجم", "۳×۳۰۰ میلی‌لیتر"), spec("نوع", "۱۰۰٪ طبیعی"), spec("قند", "بدون افزوده")], rating: 4.6, reviewCount: 52, stock: 42, category: "beverage", featured: false, department: "food" },
  { name: "مغز گردوی تازه", slug: "fresh-walnuts", description: "مغز گردوی درجه یک و تازه، سرشار از امگا ۳ و آنتی‌اکسیدان، مناسب میان‌وعده.", brand: "خشکبار طلایی", price: 320000, oldPrice: 390000, image: IMG.walnut, gallery: [IMG.walnut], specs: [spec("وزن", "۵۰۰ گرم"), spec("نوع", "مغز درجه یک"), spec("بسته‌بندی", "نظافت")], rating: 4.8, reviewCount: 91, stock: 55, badge: "محبوب", category: "snacks", featured: true, department: "food" },
  { name: "شکلات تلخ ۷۰٪", slug: "dark-chocolate", description: "شکلات تلخ ۷۰٪ با کیفیت بالا، کم‌شکر و سرشار از کاکائوی خالص.", brand: "شیرینی‌سرا", price: 165000, image: IMG.choco, gallery: [IMG.choco, IMG.walnut], specs: [spec("وزن", "۲۰۰ گرم"), spec("کاکائو", "۷۰٪"), spec("شکر", "کم")], rating: 4.5, reviewCount: 70, stock: 60, badge: "جدید", category: "snacks", featured: false, department: "food" },
];

const reviewData = [
  { slug: "aero-anc-headphones", name: "سارا محمدی", rating: 5, comment: "کیفیت صدا فوق‌العاده‌ست و حذف نویز عالی کار می‌کنه. خیلی راحته." },
  { slug: "aero-anc-headphones", name: "امیر رضایی", rating: 5, comment: "بهترین هدفونی که داشتم. باتریش واقعاً طولانی‌تر از حد انتظاره." },
  { slug: "aero-anc-headphones", name: "نگار", rating: 4, comment: "صدای عالی ولی قیمتش یه کم بالاست. در مجموع راضی‌ام." },
  { slug: "pulse-watch-7", name: "حسین کریمی", rating: 5, comment: "دقت سنسورهاش عالیه و عمر باتری فوق‌العاده‌ست." },
  { slug: "nova-ultra", name: "مریم احمدی", rating: 5, comment: "دوربینش شگفت‌انگیزه و نمایشگرش خیلی خوش‌رنگه. عاشقش شدم!" },
  { slug: "ultrabook-pro-14", name: "علی", rating: 5, comment: "سبک، سریع و باتریش کل روز رو می‌کشه. برای کار بی‌نقصه." },
  { slug: "mech-rgb-keyboard", name: "رضا", rating: 4, comment: "تایپ باهاش خیلی لذت‌بخشه. نورپردازی RGBشم خیلی خروسه." },
  { slug: "fresh-fruit-basket", name: "فاطمه", rating: 5, comment: "میوه‌ها واقعاً تازه و خوش‌طعم بودن. ارسال سریع داشتیم." },
  { slug: "fresh-milk", name: "احمد", rating: 5, comment: "شیر خالص و طعمش مثل شیر روستایی قدیم. عالی بود." },
];

export async function ensureSeeded() {
  try {
    // settings singleton
    const existingSettings = await db.select().from(settings).limit(1);
    if (existingSettings.length === 0) {
      await db.insert(settings).values({ id: 1 });
    }

    // categories - idempotent by slug
    const existingCats = await db.select({ slug: categories.slug }).from(categories);
    const catSlugs = new Set(existingCats.map((c) => c.slug));
    const newCats = categoryData.filter((c) => !catSlugs.has(c.slug));
    let catRows: { id: number; slug: string }[] = [];
    if (newCats.length) {
      catRows = await db.insert(categories).values(newCats).returning({ id: categories.id, slug: categories.slug });
    }
    const allCats = await db.select({ id: categories.id, slug: categories.slug }).from(categories);
    const catMap = new Map(allCats.map((c) => [c.slug, c.id]));

    // products - idempotent by slug
    const existingProds = await db.select({ slug: products.slug }).from(products);
    const prodSlugs = new Set(existingProds.map((p) => p.slug));
    const newProds = productData.filter((p) => !prodSlugs.has(p.slug));
    if (newProds.length) {
      const rows = newProds.map((p) => ({
        name: p.name, slug: p.slug, description: p.description, brand: p.brand,
        price: p.price, oldPrice: p.oldPrice ?? null, image: p.image, gallery: p.gallery,
        specs: p.specs, rating: p.rating, reviewCount: p.reviewCount, stock: p.stock,
        badge: p.badge ?? null, categoryId: catMap.get(p.category)!, featured: p.featured,
        department: p.department,
      }));
      const inserted = await db.insert(products).values(rows).returning({ id: products.id, slug: products.slug });
      catRows = [...catRows, ...inserted.map((i) => ({ id: i.id, slug: i.slug }))];
    }
    const allProds = await db.select({ id: products.id, slug: products.slug }).from(products);
    const prodMap = new Map(allProds.map((p) => [p.slug, p.id]));

    // reviews - only for products that don't yet have reviews
    const prodIdsWithReviews = new Set<number>();
    if (reviewData.length) {
      const r = await db.selectDistinct({ pid: reviews.productId }).from(reviews);
      r.forEach((x) => prodIdsWithReviews.add(x.pid));
      const reviewRows = reviewData
        .map((rv) => ({ productId: prodMap.get(rv.slug)!, name: rv.name, rating: rv.rating, comment: rv.comment }))
        .filter((rv) => rv.productId && !prodIdsWithReviews.has(rv.productId));
      if (reviewRows.length) await db.insert(reviews).values(reviewRows);
    }
    void catRows;
    void inArray;
  } catch {
    // دیتابیس یا جداول هنوز آماده نیستند (مثلاً هنگام build) — نادیده گرفته می‌شود
  }
}
