import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  jsonb,
  real,
  boolean,
} from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon"),
  color: text("color"),
  description: text("description"),
  department: text("department").notNull().default("tech"),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  brand: text("brand"),
  price: integer("price").notNull(),
  oldPrice: integer("old_price"),
  image: text("image").notNull(),
  gallery: jsonb("gallery").$type<string[]>(),
  specs: jsonb("specs").$type<{ label: string; value: string }[]>(),
  rating: real("rating").notNull().default(0),
  reviewCount: integer("review_count").notNull().default(0),
  stock: integer("stock").notNull().default(0),
  badge: text("badge"),
  categoryId: integer("category_id").references(() => categories.id),
  featured: boolean("featured").notNull().default(false),
  department: text("department").notNull().default("tech"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .references(() => products.id, { onDelete: "cascade" })
    .notNull(),
  name: text("name").notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  city: text("city"),
  notes: text("notes"),
  total: integer("total").notNull(),
  status: text("status").notNull().default("در حال پردازش"),
  items: jsonb("items").$type<
    { id: number; name: string; price: number; qty: number; image: string }[]
  >(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  name: text("name"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const settings = pgTable("settings", {
  id: integer("id").primaryKey(),
  heroBadge: text("hero_badge").notNull().default("جشنواره فروش پاییزه آغاز شد"),
  heroTitle: text("hero_title").notNull().default("دنیای"),
  heroHighlight: text("hero_highlight").notNull().default("تکنولوژی"),
  heroSubtitle: text("hero_subtitle").notNull().default(
    "جدیدترین موبایل، لپ‌تاپ، هدفون و گجت‌های هوشمند را با ضمانت اصالت کالا، قیمت منصفانه و ارسال رایگان از لوکسا خرید کنید.",
  ),
  announcementText: text("announcement_text").notNull().default(
    "ارسال رایگان برای سفارش‌های بالای ۵,۰۰۰,۰۰۰ تومان • ضمانت اصالت کالا",
  ),
  freeShipThreshold: integer("free_ship_threshold").notNull().default(5000000),
  shippingFee: integer("shipping_fee").notNull().default(250000),
  primaryColor: text("primary_color").notNull().default("#7c3aed"),
  accentColor: text("accent_color").notNull().default("#ec4899"),
  contactPhone: text("contact_phone").notNull().default("۰۲۱-۹۱۰۰۰۰۰۰"),
  contactEmail: text("contact_email").notNull().default("support@luxa.ir"),
  contactAddress: text("contact_address").notNull().default(
    "تهران، خیابان ولیعصر",
  ),
  showFood: boolean("show_food").notNull().default(true),
});

export type Category = typeof categories.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Media = typeof media.$inferSelect;
export type Setting = typeof settings.$inferSelect;

export const DEPARTMENTS = [
  { id: "tech", name: "دیجیتال و کالای دیجیتال", icon: "💻", short: "دیجیتال" },
  { id: "food", name: "مواد غذایی و سوپرمارکت", icon: "🛒", short: "خوراک" },
] as const;
