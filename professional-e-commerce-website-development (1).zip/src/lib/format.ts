export const faNum = (n: number) => new Intl.NumberFormat("fa-IR").format(n);

export function formatPrice(n: number) {
  return faNum(n) + " تومان";
}

export function formatDate(d: Date | string) {
  return new Intl.DateTimeFormat("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(d));
}

export function discountPercent(price: number, oldPrice?: number | null) {
  if (!oldPrice || oldPrice <= price) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}
