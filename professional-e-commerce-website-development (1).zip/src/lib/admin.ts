import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { NextResponse } from "next/server";
import crypto from "crypto";

export const ADMIN_PASSWORD = "138989";

/** گارد برای APIهای ادمین — در صورت عدم احراز هویت پاسخ ۴۰۱ می‌دهد */
export async function apiGuard(): Promise<NextResponse | null> {
  const ok = await isLoggedIn();
  if (!ok) return NextResponse.json({ error: "احراز هویت نشده" }, { status: 401 });
  return null;
}

const COOKIE_NAME = "luxa_admin";
const SECRET = process.env.ADMIN_SECRET || "luxa-admin-secret-key-2026";

function signToken() {
  // توکن = expiry + امضای HMAC
  const exp = Date.now() + 1000 * 60 * 60 * 24 * 7; // ۷ روز
  const payload = `admin:${exp}`;
  const sig = crypto.createHmac("sha256", SECRET).update(payload).digest("hex");
  return `${payload}.${sig}`;
}

export function verifyToken(token: string | undefined): boolean {
  if (!token) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  const expected = crypto.createHmac("sha256", SECRET).update(payload).digest("hex");
  // جلوگیری از حمله زمان‌سنجی
  if (sig.length !== expected.length) return false;
  try {
    const timingSafe = crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
    if (!timingSafe) return false;
  } catch {
    return false;
  }
  const [, expStr] = payload.split(":");
  const exp = Number(expStr);
  if (!exp || Date.now() > exp) return false;
  return true;
}

export async function isLoggedIn(): Promise<boolean> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  return verifyToken(token);
}

export async function requireAdmin() {
  const ok = await isLoggedIn();
  if (!ok) redirect("/admin/login");
}

export async function setAdminCookie() {
  const store = await cookies();
  store.set(COOKIE_NAME, signToken(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearAdminCookie() {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

/** رنگ سبک‌تر/تیره‌تر برای طیف کامل از یک رنگ پایه */
export function buildColorVars(primary: string, accent: string) {
  const mix = (color: string, pct: number, base: string) =>
    `color-mix(in srgb, ${color} ${pct}%, ${base})`;
  return `:root{
--color-brand-50:${mix(primary, 8, "white")};
--color-brand-100:${mix(primary, 16, "white")};
--color-brand-200:${mix(primary, 28, "white")};
--color-brand-300:${mix(primary, 45, "white")};
--color-brand-400:${mix(primary, 70, "white")};
--color-brand-500:${primary};
--color-brand-600:${mix(primary, 90, "black")};
--color-brand-700:${mix(primary, 75, "black")};
--color-brand-800:${mix(primary, 60, "black")};
--color-brand-900:${mix(primary, 48, "black")};
--color-fuchsia-500:${accent};
--color-fuchsia-600:${mix(accent, 88, "black")};
}`;
}
