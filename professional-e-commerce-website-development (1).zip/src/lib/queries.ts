import { db } from "@/db";
import { products, categories, reviews, settings, media, orders } from "@/db/schema";
import { eq, desc, asc, ne, and, sql } from "drizzle-orm";

export async function getSettings() {
  const rows = await db.select().from(settings).limit(1);
  return rows[0];
}

export async function getAllCategories() {
  return db.select().from(categories).orderBy(asc(categories.id));
}

export async function getCategoriesByDepartment(dept: string) {
  return db
    .select()
    .from(categories)
    .where(eq(categories.department, dept))
    .orderBy(asc(categories.id));
}

export async function getAllProducts() {
  return db.select().from(products).orderBy(desc(products.createdAt));
}

export async function getProductsByDepartment(dept: string) {
  return db
    .select()
    .from(products)
    .where(eq(products.department, dept))
    .orderBy(desc(products.createdAt));
}

export async function getFeaturedProducts(limit = 8) {
  return db.select().from(products).where(eq(products.featured, true)).limit(limit);
}

export async function getFeaturedByDepartment(dept: string, limit = 8) {
  return db
    .select()
    .from(products)
    .where(and(eq(products.featured, true), eq(products.department, dept)))
    .limit(limit);
}

export async function getProductBySlug(slug: string) {
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return rows[0];
}

export async function getRelatedProducts(categoryId: number, excludeId: number, limit = 4) {
  return db
    .select()
    .from(products)
    .where(and(eq(products.categoryId, categoryId), ne(products.id, excludeId)))
    .limit(limit);
}

export async function getProductReviews(productId: number) {
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt));
}

export async function getAllMedia() {
  return db.select().from(media).orderBy(desc(media.createdAt));
}

export async function getDashboardStats() {
  const [p] = await db.select({ c: sql<number>`count(*)::int` }).from(products);
  const [o] = await db.select({ c: sql<number>`count(*)::int` }).from(orders);
  const [rev] = await db.select({ c: sql<number>`count(*)::int` }).from(reviews);
  const [revSum] = await db.select({ s: sql<number>`coalesce(sum(${orders.total}),0)::int` }).from(orders);
  const [low] = await db.select({ c: sql<number>`count(*)::int` }).from(products).where(sql`${products.stock} < 10`);
  return {
    productCount: p?.c ?? 0,
    orderCount: o?.c ?? 0,
    reviewCount: rev?.c ?? 0,
    revenue: revSum?.s ?? 0,
    lowStock: low?.c ?? 0,
  };
}
